package Servicios;

import java.sql.SQLException;
import java.util.List;
import BD.ProductoBD;
import Modelo.Producto;

public class InventarioServicio {
    private final ProductoBD productoBD = new ProductoBD();
    public boolean registrarProducto(String nombre, double precio, int stock) throws SQLException {
        validar(nombre, precio, stock);
        return productoBD.registrarProducto(new Producto(nombre.trim(), precio, stock));
    }
    public List<Producto> consultarProductos() throws SQLException { return productoBD.consultarProductos(); }
    public boolean modificarProducto(int id, String nombre, double precio, int stock) throws SQLException {
        if (id <= 0) throw new IllegalArgumentException("Selecciona un producto válido.");
        validar(nombre, precio, stock);
        return productoBD.modificarProducto(new Producto(id, nombre.trim(), precio, stock));
    }
    public boolean eliminarProducto(int id) throws SQLException {
        if (id <= 0) throw new IllegalArgumentException("Selecciona un producto válido.");
        return productoBD.eliminarProducto(id);
    }
    private void validar(String nombre, double precio, int stock) {
        if (nombre == null || nombre.trim().isEmpty()) throw new IllegalArgumentException("El nombre es obligatorio.");
        if (!Double.isFinite(precio) || precio <= 0) throw new IllegalArgumentException("El precio debe ser mayor que cero.");
        if (stock < 0) throw new IllegalArgumentException("El stock no puede ser negativo.");
    }
}
