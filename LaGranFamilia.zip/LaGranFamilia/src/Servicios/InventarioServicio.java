package Servicios;

public class InventarioServicio {

}
