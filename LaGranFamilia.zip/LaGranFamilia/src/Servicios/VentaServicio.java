package Servicios;

/** Objeto sencillo para representar los datos calculados de una venta. */
public class VentaServicio {
    private final int folio;
    private final String producto;
    private final int cantidad;
    private final double precio;
    private final double total;
    public VentaServicio(int folio, String producto, int cantidad, double precio) {
        this.folio=folio; this.producto=producto; this.cantidad=cantidad; this.precio=precio; this.total=cantidad*precio;
    }
    public int getFolio(){return folio;}
    public String getProducto(){return producto;}
    public int getCantidad(){return cantidad;}
    public double getPrecio(){return precio;}
    public double getTotal(){return total;}
}
