package Servicios;

import java.sql.SQLException;
import java.util.Map;

import BD.VentaBD;
import Modelo.ResultadoVenta;

public class GestorVentas {
    private final VentaBD ventaBD = new VentaBD();

    public ResultadoVenta realizarVenta(int idUsuario, int idProducto, int cantidad) throws SQLException {
        return ventaBD.registrarVenta(idUsuario, idProducto, cantidad);
    }

    public ResultadoVenta realizarVenta(int idUsuario, Map<Integer, Integer> carrito) throws SQLException {
        return ventaBD.registrarVenta(idUsuario, carrito);
    }
}
