package Servicios;

import javax.swing.SwingUtilities;
import Interfaz.Login;

/** Punto de entrada de compatibilidad: inicia la aplicación gráfica. */
public class Programa {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Login().setVisible(true));
    }
}
