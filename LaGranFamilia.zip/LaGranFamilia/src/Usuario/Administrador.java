package Usuario;

public class Administrador {
    private final int idUsuario;
    private final String nombre;
    public Administrador(int idUsuario, String nombre) { this.idUsuario = idUsuario; this.nombre = nombre; }
    public int getIdUsuario() { return idUsuario; }
    public String getNombre() { return nombre; }
}
