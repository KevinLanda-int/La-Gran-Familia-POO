package Usuario;

public class Empleado {
    private final int idUsuario;
    private final String nombre;
    public Empleado(int idUsuario, String nombre) { this.idUsuario = idUsuario; this.nombre = nombre; }
    public int getIdUsuario() { return idUsuario; }
    public String getNombre() { return nombre; }
}
