package Principal;

import javax.swing.SwingUtilities;
import Interfaz.Login;

public class principal {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Login().setVisible(true));
    }
}
