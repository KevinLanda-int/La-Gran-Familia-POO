package Modelo;

public class Producto {
    private int id_producto;
    private String nombre;
    private double precio;
    private int stock;

    public Producto() { }
    public Producto(int id_producto, String nombre, double precio, int stock) {
        this.id_producto = id_producto; this.nombre = nombre; this.precio = precio; this.stock = stock;
    }
    public Producto(String nombre, double precio, int stock) {
        this(0, nombre, precio, stock);
    }
    public int getId_producto() { return id_producto; }
    public void setId_producto(int id_producto) { this.id_producto = id_producto; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public double getPrecio() { return precio; }
    public void setPrecio(double precio) { this.precio = precio; }
    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }
    @Override public String toString() {
        return id_producto + " - " + nombre + " | $" + String.format(java.util.Locale.US, "%.2f", precio) + " | Stock: " + stock;
    }
}
