package Modelo;

import java.time.LocalDateTime;

public class Venta {
    private int idVenta;
    private LocalDateTime fecha;
    private double total;
    private int idUsuario;
    private String nombreUsuario;

    public Venta(int idVenta, LocalDateTime fecha, double total, int idUsuario, String nombreUsuario) {
        this.idVenta = idVenta; this.fecha = fecha; this.total = total;
        this.idUsuario = idUsuario; this.nombreUsuario = nombreUsuario;
    }
    public int getIdVenta() { return idVenta; }
    public LocalDateTime getFecha() { return fecha; }
    public double getTotal() { return total; }
    public int getIdUsuario() { return idUsuario; }
    public String getNombreUsuario() { return nombreUsuario; }
}
