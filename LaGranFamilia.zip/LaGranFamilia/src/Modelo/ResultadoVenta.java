package Modelo;

public class ResultadoVenta {
    private final int idVenta;
    private final String nombreProducto;
    private final int cantidad;
    private final double precioUnitario;
    private final double total;

    public ResultadoVenta(int idVenta, String nombreProducto, int cantidad, double precioUnitario, double total) {
        this.idVenta = idVenta; this.nombreProducto = nombreProducto; this.cantidad = cantidad;
        this.precioUnitario = precioUnitario; this.total = total;
    }
    public int getIdVenta() { return idVenta; }
    public String getNombreProducto() { return nombreProducto; }
    public int getCantidad() { return cantidad; }
    public double getPrecioUnitario() { return precioUnitario; }
    public double getTotal() { return total; }
}
