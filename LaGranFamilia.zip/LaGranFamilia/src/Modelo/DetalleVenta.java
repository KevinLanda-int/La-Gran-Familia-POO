package Modelo;

public class DetalleVenta {
    private int idDetalle;
    private int idVenta;
    private int idProducto;
    private String nombreProducto;
    private int cantidad;
    private double precioUnitario;
    private double subtotal;

    public DetalleVenta(int idDetalle, int idVenta, int idProducto, String nombreProducto,
                        int cantidad, double precioUnitario, double subtotal) {
        this.idDetalle = idDetalle; this.idVenta = idVenta; this.idProducto = idProducto;
        this.nombreProducto = nombreProducto; this.cantidad = cantidad;
        this.precioUnitario = precioUnitario; this.subtotal = subtotal;
    }
    public int getIdDetalle() { return idDetalle; }
    public int getIdVenta() { return idVenta; }
    public int getIdProducto() { return idProducto; }
    public String getNombreProducto() { return nombreProducto; }
    public int getCantidad() { return cantidad; }
    public double getPrecioUnitario() { return precioUnitario; }
    public double getSubtotal() { return subtotal; }
}
