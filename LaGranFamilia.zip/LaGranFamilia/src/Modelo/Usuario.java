package Modelo;

public class Usuario {
    private final int idUsuario;
    private final String nombre;
    private final String usuario;
    private final String rol;

    public Usuario(int idUsuario, String nombre, String usuario, String rol) {
        this.idUsuario = idUsuario; this.nombre = nombre; this.usuario = usuario; this.rol = rol;
    }
    public int getIdUsuario() { return idUsuario; }
    public String getNombre() { return nombre; }
    public String getUsuario() { return usuario; }
    public String getRol() { return rol; }
}
