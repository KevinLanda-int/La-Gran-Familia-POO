package BD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import Modelo.Producto;

public class ProductoBD {
    public boolean registrarProducto(Producto producto) throws SQLException {
        String sql = "INSERT INTO producto (nombre, precio, stock) VALUES (?, ?, ?)";
        try (Connection con = Conexion.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, producto.getNombre()); ps.setDouble(2, producto.getPrecio()); ps.setInt(3, producto.getStock());
            return ps.executeUpdate() == 1;
        }
    }
    public List<Producto> consultarProductos() throws SQLException {
        List<Producto> lista = new ArrayList<>();
        String sql = "SELECT id_producto, nombre, precio, stock FROM producto ORDER BY nombre";
        try (Connection con = Conexion.conectar(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) lista.add(new Producto(rs.getInt("id_producto"), rs.getString("nombre"), rs.getDouble("precio"), rs.getInt("stock")));
        }
        return lista;
    }
    public boolean modificarProducto(Producto p) throws SQLException {
        String sql = "UPDATE producto SET nombre=?, precio=?, stock=? WHERE id_producto=?";
        try (Connection con = Conexion.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, p.getNombre()); ps.setDouble(2, p.getPrecio()); ps.setInt(3, p.getStock()); ps.setInt(4, p.getId_producto());
            return ps.executeUpdate() == 1;
        }
    }
    public boolean eliminarProducto(int id) throws SQLException {
        String sql = "DELETE FROM producto WHERE id_producto=?";
        try (Connection con = Conexion.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id); return ps.executeUpdate() == 1;
        }
    }
}
