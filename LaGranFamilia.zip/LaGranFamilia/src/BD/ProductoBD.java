package BD;

public class ProductoBD {

}
