package BD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import Modelo.DetalleVenta;
import Modelo.ResultadoVenta;
import Modelo.Venta;

public class VentaBD {

    /** Registra una venta con uno o varios productos en una sola transacción. */
    public ResultadoVenta registrarVenta(int idUsuario, Map<Integer, Integer> productos) throws SQLException {
        if (idUsuario <= 0) throw new SQLException("El usuario no es válido.");
        if (productos == null || productos.isEmpty()) throw new SQLException("Agrega al menos un producto al carrito.");

        // Copia estable del carrito; rechaza cantidades inválidas.
        Map<Integer, Integer> carrito = new LinkedHashMap<>();
        for (Map.Entry<Integer, Integer> item : productos.entrySet()) {
            if (item.getKey() == null || item.getKey() <= 0 || item.getValue() == null || item.getValue() <= 0) {
                throw new SQLException("Hay un producto o una cantidad inválida en el carrito.");
            }
            carrito.merge(item.getKey(), item.getValue(), Integer::sum);
        }

        try (Connection con = Conexion.conectar()) {
            con.setAutoCommit(false);
            try {
                class ProductoVenta {
                    int id; String nombre; double precio; int stock; int cantidad;
                    ProductoVenta(int id, String nombre, double precio, int stock, int cantidad) {
                        this.id=id; this.nombre=nombre; this.precio=precio; this.stock=stock; this.cantidad=cantidad;
                    }
                }
                List<ProductoVenta> detalle = new ArrayList<>();
                double total = 0.0;
                int cantidadTotal = 0;

                // Bloquea y valida cada producto para evitar vender existencias insuficientes.
                String sqlProducto = "SELECT nombre, precio, stock FROM producto WHERE id_producto=? FOR UPDATE";
                try (PreparedStatement ps = con.prepareStatement(sqlProducto)) {
                    for (Map.Entry<Integer, Integer> item : carrito.entrySet()) {
                        ps.setInt(1, item.getKey());
                        try (ResultSet rs = ps.executeQuery()) {
                            if (!rs.next()) throw new SQLException("El producto con ID " + item.getKey() + " ya no existe.");
                            String nombre = rs.getString("nombre");
                            double precio = rs.getDouble("precio");
                            int stock = rs.getInt("stock");
                            int cantidad = item.getValue();
                            if (stock < cantidad) {
                                throw new SQLException("Stock insuficiente para '" + nombre + "'. Disponible: " + stock + ", solicitado: " + cantidad + ".");
                            }
                            detalle.add(new ProductoVenta(item.getKey(), nombre, precio, stock, cantidad));
                            total += precio * cantidad;
                            cantidadTotal += cantidad;
                        }
                    }
                }

                int idVenta;
                try (PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO venta (fecha, total, id_usuario) VALUES (NOW(), ?, ?)",
                        Statement.RETURN_GENERATED_KEYS)) {
                    ps.setDouble(1, total);
                    ps.setInt(2, idUsuario);
                    if (ps.executeUpdate() != 1) throw new SQLException("No se pudo guardar la venta.");
                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        if (!keys.next()) throw new SQLException("No se obtuvo el folio de la venta.");
                        idVenta = keys.getInt(1);
                    }
                }

                String sqlDetalle = "INSERT INTO detalle_venta (id_venta, id_producto, cantidad, precio_unitario, subtotal) VALUES (?, ?, ?, ?, ?)";
                String sqlStock = "UPDATE producto SET stock = stock - ? WHERE id_producto = ? AND stock >= ?";
                try (PreparedStatement psDetalle = con.prepareStatement(sqlDetalle);
                     PreparedStatement psStock = con.prepareStatement(sqlStock)) {
                    for (ProductoVenta item : detalle) {
                        double subtotal = item.precio * item.cantidad;
                        psDetalle.setInt(1, idVenta);
                        psDetalle.setInt(2, item.id);
                        psDetalle.setInt(3, item.cantidad);
                        psDetalle.setDouble(4, item.precio);
                        psDetalle.setDouble(5, subtotal);
                        psDetalle.executeUpdate();

                        psStock.setInt(1, item.cantidad);
                        psStock.setInt(2, item.id);
                        psStock.setInt(3, item.cantidad);
                        if (psStock.executeUpdate() != 1) {
                            throw new SQLException("No se pudo actualizar el inventario de '" + item.nombre + "'.");
                        }
                    }
                }

                con.commit();
                return new ResultadoVenta(idVenta, detalle.size() + " producto(s) diferentes", cantidadTotal, 0.0, total);
            } catch (SQLException | RuntimeException ex) {
                try { con.rollback(); } catch (SQLException rollbackEx) { ex.addSuppressed(rollbackEx); }
                if (ex instanceof SQLException) throw (SQLException) ex;
                throw ex;
            } finally {
                try { con.setAutoCommit(true); } catch (SQLException ignored) { }
            }
        }
    }

    /** Compatibilidad con llamadas antiguas de venta de un solo producto. */
    public ResultadoVenta registrarVenta(int idUsuario, int idProducto, int cantidad) throws SQLException {
        Map<Integer, Integer> carrito = new LinkedHashMap<>();
        carrito.put(idProducto, cantidad);
        return registrarVenta(idUsuario, carrito);
    }

    public List<Venta> consultarVentas() throws SQLException {
        List<Venta> lista = new ArrayList<>();
        String sql = "SELECT v.id_venta, v.fecha, v.total, v.id_usuario, u.nombre FROM venta v JOIN usuario u ON u.id_usuario=v.id_usuario ORDER BY v.id_venta DESC";
        try (Connection con = Conexion.conectar(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) lista.add(new Venta(rs.getInt("id_venta"), rs.getTimestamp("fecha").toLocalDateTime(), rs.getDouble("total"), rs.getInt("id_usuario"), rs.getString("nombre")));
        }
        return lista;
    }

    public List<DetalleVenta> consultarDetalles(int idVenta) throws SQLException {
        List<DetalleVenta> lista = new ArrayList<>();
        String sql = "SELECT d.id_detalle, d.id_venta, d.id_producto, p.nombre, d.cantidad, d.precio_unitario, d.subtotal FROM detalle_venta d JOIN producto p ON p.id_producto=d.id_producto WHERE d.id_venta=? ORDER BY d.id_detalle";
        try (Connection con = Conexion.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idVenta);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) lista.add(new DetalleVenta(rs.getInt("id_detalle"), rs.getInt("id_venta"), rs.getInt("id_producto"), rs.getString("nombre"), rs.getInt("cantidad"), rs.getDouble("precio_unitario"), rs.getDouble("subtotal")));
            }
        }
        return lista;
    }
}
