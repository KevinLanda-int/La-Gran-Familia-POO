package BD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
	public static void main(String[] args) {

        String url = "jdbc:mysql://localhost:3306/LaGranFamilia";
        String usuario = "root";
        String password = "ROOT";

        try {
            Connection Conexion = DriverManager.getConnection(url, usuario, password);
            System.out.println("¡Conexión exitosa a MySQL!");
            
        } catch (SQLException e) {
            System.out.println("Error en la conexión: " + e.getMessage());
        }
    }
}

