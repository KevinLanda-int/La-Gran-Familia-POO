package Interfaz;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import BD.ProductoBD;
import Modelo.Producto;
import Modelo.ResultadoVenta;
import Servicios.GestorVentas;

public class Ventas extends JFrame {
    private final int idUsuario;
    private final JComboBox<Producto> cmbProducto = new JComboBox<>();
    private final JTextField txtCantidad = new JTextField("1");
    private final JTextField txtPrecio = new JTextField();
    private final JTextField txtTotal = new JTextField("$0.00");
    private final DefaultTableModel modeloCarrito = new DefaultTableModel(
            new Object[]{"ID", "Producto", "Cantidad", "Precio", "Subtotal"}, 0) {
        @Override public boolean isCellEditable(int fila, int columna) { return false; }
    };
    private final JTable tablaCarrito = new JTable(modeloCarrito);
    private final Map<Integer, Integer> carrito = new LinkedHashMap<>();
    private final GestorVentas gestor = new GestorVentas();
    private final ProductoBD productoBD = new ProductoBD();

    public Ventas() { this(1); }

    public Ventas(int idUsuario) {
        this.idUsuario = idUsuario;
        setTitle("La Gran Familia - Registrar venta");
        setSize(760, 570);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        JPanel p = new JPanel(null);
        p.setBackground(new Color(255, 220, 80));
        setContentPane(p);

        JLabel title = new JLabel("REGISTRAR VENTA", SwingConstants.CENTER);
        title.setFont(new Font("Serif", Font.BOLD, 24));
        title.setBounds(20, 12, 705, 35);
        p.add(title);

        JLabel lp = new JLabel("Producto:"); lp.setBounds(25, 60, 90, 25); p.add(lp);
        cmbProducto.setBounds(115, 60, 365, 28); p.add(cmbProducto);
        JLabel lc = new JLabel("Cantidad:"); lc.setBounds(25, 98, 90, 25); p.add(lc);
        txtCantidad.setBounds(115, 98, 90, 28); p.add(txtCantidad);
        JLabel lpr = new JLabel("Precio:"); lpr.setBounds(225, 98, 55, 25); p.add(lpr);
        txtPrecio.setEditable(false); txtPrecio.setBounds(280, 98, 100, 28); p.add(txtPrecio);
        JLabel lt = new JLabel("Total de la venta:"); lt.setFont(new Font("Arial", Font.BOLD, 15)); lt.setBounds(500, 98, 135, 25); p.add(lt);
        txtTotal.setEditable(false); txtTotal.setFont(new Font("Arial", Font.BOLD, 16)); txtTotal.setBounds(630, 96, 95, 30); p.add(txtTotal);

        JButton btnAgregar = new JButton("Agregar producto"); btnAgregar.setBounds(490, 60, 145, 28); p.add(btnAgregar);
        JButton btnQuitar = new JButton("Quitar seleccionado"); btnQuitar.setBounds(490, 135, 145, 30); p.add(btnQuitar);
        JButton btnLimpiar = new JButton("Vaciar carrito"); btnLimpiar.setBounds(640, 135, 90, 30); p.add(btnLimpiar);

        JLabel lcarr = new JLabel("PRODUCTOS DE ESTA VENTA");
        lcarr.setFont(new Font("Serif", Font.BOLD, 16)); lcarr.setBounds(25, 140, 300, 25); p.add(lcarr);
        tablaCarrito.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tablaCarrito.setRowHeight(23);
        JScrollPane scroll = new JScrollPane(tablaCarrito); scroll.setBounds(25, 175, 705, 275); p.add(scroll);

        JButton btnRegistrar = new JButton("Registrar venta completa");
        btnRegistrar.setFont(new Font("Arial", Font.BOLD, 14));
        btnRegistrar.setBackground(new Color(204, 204, 0));
        btnRegistrar.setBounds(220, 470, 230, 38); p.add(btnRegistrar);
        JButton btnActualizar = new JButton("Actualizar inventario"); btnActualizar.setBounds(475, 470, 200, 38); p.add(btnActualizar);

        cmbProducto.addActionListener(e -> actualizarPrecio());
        btnAgregar.addActionListener(e -> agregarProducto());
        btnQuitar.addActionListener(e -> quitarProducto());
        btnLimpiar.addActionListener(e -> vaciarCarrito());
        btnRegistrar.addActionListener(e -> registrar());
        btnActualizar.addActionListener(e -> cargarProductos());
        cargarProductos();
    }

    private void cargarProductos() {
        try {
            Producto seleccionado = (Producto) cmbProducto.getSelectedItem();
            int idSeleccionado = seleccionado == null ? -1 : seleccionado.getId_producto();
            cmbProducto.removeAllItems();
            List<Producto> productos = productoBD.consultarProductos();
            for (Producto p : productos) {
                if (p.getStock() > 0) cmbProducto.addItem(p);
            }
            for (int i = 0; i < cmbProducto.getItemCount(); i++) {
                if (cmbProducto.getItemAt(i).getId_producto() == idSeleccionado) {
                    cmbProducto.setSelectedIndex(i);
                    break;
                }
            }
            actualizarPrecio();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "No se pudo cargar el inventario: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void actualizarPrecio() {
        Producto p = (Producto) cmbProducto.getSelectedItem();
        if (p == null) { txtPrecio.setText(""); return; }
        txtPrecio.setText(String.format(java.util.Locale.US, "%.2f", p.getPrecio()));
    }

    private int cantidadSolicitada() {
        int c = Integer.parseInt(txtCantidad.getText().trim());
        if (c <= 0) throw new NumberFormatException();
        return c;
    }

    private void agregarProducto() {
        Producto p = (Producto) cmbProducto.getSelectedItem();
        if (p == null) {
            JOptionPane.showMessageDialog(this, "No hay productos con existencias disponibles.");
            return;
        }
        try {
            int cantidad = cantidadSolicitada();
            int yaAgregado = carrito.getOrDefault(p.getId_producto(), 0);
            int nuevaCantidad = yaAgregado + cantidad;
            if (nuevaCantidad > p.getStock()) {
                JOptionPane.showMessageDialog(this, "Stock insuficiente para " + p.getNombre() + ". Disponible: " + p.getStock() + ". Ya agregado: " + yaAgregado + ".");
                return;
            }
            carrito.put(p.getId_producto(), nuevaCantidad);
            refrescarCarrito();
            txtCantidad.setText("1");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "La cantidad debe ser un entero mayor que cero.");
        }
    }

    private void quitarProducto() {
        int fila = tablaCarrito.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(this, "Selecciona un producto del carrito.");
            return;
        }
        int id = Integer.parseInt(modeloCarrito.getValueAt(fila, 0).toString());
        carrito.remove(id);
        refrescarCarrito();
    }

    private void vaciarCarrito() {
        carrito.clear();
        refrescarCarrito();
    }

    private void refrescarCarrito() {
        modeloCarrito.setRowCount(0);
        double total = 0.0;
        for (Map.Entry<Integer, Integer> item : carrito.entrySet()) {
            Producto producto = buscarProducto(item.getKey());
            if (producto == null) continue;
            int cantidad = item.getValue();
            double subtotal = producto.getPrecio() * cantidad;
            total += subtotal;
            modeloCarrito.addRow(new Object[]{producto.getId_producto(), producto.getNombre(), cantidad,
                    String.format(java.util.Locale.US, "$%.2f", producto.getPrecio()),
                    String.format(java.util.Locale.US, "$%.2f", subtotal)});
        }
        txtTotal.setText(String.format(java.util.Locale.US, "$%.2f", total));
    }

    private Producto buscarProducto(int id) {
        for (int i = 0; i < cmbProducto.getItemCount(); i++) {
            Producto p = cmbProducto.getItemAt(i);
            if (p.getId_producto() == id) return p;
        }
        // Si el producto deja de estar disponible en el combo, consultamos el inventario completo.
        try {
            for (Producto p : productoBD.consultarProductos()) if (p.getId_producto() == id) return p;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "No se pudo consultar el producto: " + ex.getMessage());
        }
        return null;
    }

    private void registrar() {
        if (carrito.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Agrega uno o más productos antes de registrar la venta.");
            return;
        }
        int confirmar = JOptionPane.showConfirmDialog(this,
                "¿Registrar la venta con " + carrito.size() + " producto(s) diferente(s) por " + txtTotal.getText() + "?",
                "Confirmar venta", JOptionPane.YES_NO_OPTION);
        if (confirmar != JOptionPane.YES_OPTION) return;

        try {
            // Pasamos una copia para que el carrito visual no se modifique durante la operación.
            ResultadoVenta resultado = gestor.realizarVenta(idUsuario, new LinkedHashMap<>(carrito));
            JOptionPane.showMessageDialog(this,
                    "¡Venta registrada correctamente!\nFolio: " + resultado.getIdVenta()
                    + "\nProductos diferentes: " + carrito.size()
                    + "\nUnidades: " + resultado.getCantidad()
                    + "\nTotal: $" + String.format(java.util.Locale.US, "%.2f", resultado.getTotal()),
                    "Venta completada", JOptionPane.INFORMATION_MESSAGE);
            carrito.clear();
            refrescarCarrito();
            txtCantidad.setText("1");
            cargarProductos();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "No se pudo registrar la venta:\n" + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            cargarProductos();
        }
    }
}
