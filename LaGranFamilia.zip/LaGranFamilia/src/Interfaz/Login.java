package Interfaz;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import BD.UsuarioBD;
import Modelo.Usuario;

public class Login extends JFrame {
    private final JTextField txtUsuario = new JTextField();
    private final JPasswordField txtContrasena = new JPasswordField();
    private final UsuarioBD usuarioBD = new UsuarioBD();

    public Login() {
        setTitle("Inicio de sesión - La Gran Familia");
        setSize(430, 320); setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); setResizable(false);
        JPanel panel = new JPanel(null); panel.setBackground(new Color(255, 193, 7));
        JLabel titulo = new JLabel("LA GRAN FAMILIA", SwingConstants.CENTER);
        titulo.setFont(new Font("Serif", Font.BOLD, 24)); titulo.setBounds(35, 25, 350, 35); panel.add(titulo);
        JLabel lblUsuario = new JLabel("Usuario:"); lblUsuario.setFont(new Font("Arial", Font.PLAIN, 16)); lblUsuario.setBounds(40, 90, 100, 25); panel.add(lblUsuario);
        txtUsuario.setBounds(150, 90, 230, 30); panel.add(txtUsuario);
        JLabel lblPass = new JLabel("Contraseña:"); lblPass.setFont(new Font("Arial", Font.PLAIN, 16)); lblPass.setBounds(40, 135, 105, 25); panel.add(lblPass);
        txtContrasena.setBounds(150, 135, 230, 30); panel.add(txtContrasena);
        JButton btn = new JButton("Iniciar sesión"); btn.setBounds(110, 195, 210, 36); btn.setBackground(new Color(204, 204, 0)); panel.add(btn);
        btn.addActionListener(e -> iniciarSesion()); getRootPane().setDefaultButton(btn); setContentPane(panel);
    }

    private void iniciarSesion() {
        String usuario = txtUsuario.getText().trim();
        String contrasena = new String(txtContrasena.getPassword());
        if (usuario.isEmpty() || contrasena.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingresa tu usuario y contraseña.", "Datos incompletos", JOptionPane.WARNING_MESSAGE); return;
        }
        try {
            Usuario encontrado = usuarioBD.autenticar(usuario, contrasena);
            if (encontrado == null) {
                JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos.", "Acceso denegado", JOptionPane.ERROR_MESSAGE);
                txtContrasena.setText(""); txtContrasena.requestFocus(); return;
            }
            String rol = encontrado.getRol() == null ? "" : encontrado.getRol().trim();
            JFrame menu;
            if (rol.equalsIgnoreCase("Administrador")) menu = new MenuAdministrador(encontrado.getIdUsuario(), encontrado.getNombre());
            else if (rol.equalsIgnoreCase("Empleado")) menu = new MenuEmpleado(encontrado.getIdUsuario(), encontrado.getNombre());
            else { JOptionPane.showMessageDialog(this, "El usuario tiene un rol no reconocido: " + rol); return; }
            menu.setVisible(true); dispose();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "No se pudo validar el usuario en MySQL.\n" + ex.getMessage(), "Error de conexión", JOptionPane.ERROR_MESSAGE);
        }
    }
    public static void main(String[] args) { SwingUtilities.invokeLater(() -> new Login().setVisible(true)); }
}
