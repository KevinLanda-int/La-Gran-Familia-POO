package Interfaz;

import BD.Conexion;
import Modelo.Venta;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Reporte de ventas por rango de fechas, con exportación a PDF sin librerías externas. */
public class ReporteVentas extends JFrame {
    private final JSpinner fechaInicio = selectorFecha();
    private final JSpinner fechaFin = selectorFecha();
    private final DefaultTableModel modelo = new DefaultTableModel(
            new Object[]{"Folio", "Fecha", "Empleado", "Total"}, 0) {
        @Override public boolean isCellEditable(int fila, int columna) { return false; }
    };
    private final JTable tabla = new JTable(modelo);
    private final JLabel lblResumen = new JLabel("Ventas: 0     Total vendido: $0.00");
    private final List<Venta> ventasActuales = new ArrayList<>();
    private double totalActual = 0.0;
    private final DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    public ReporteVentas() {
        setTitle("La Gran Familia - Reporte de ventas");
        setSize(850, 530);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JLabel titulo = new JLabel("REPORTE DE VENTAS", SwingConstants.CENTER);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 22));
        titulo.setBorder(BorderFactory.createEmptyBorder(12, 8, 4, 8));
        add(titulo, BorderLayout.NORTH);

        JPanel filtros = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 8));
        filtros.add(new JLabel("Desde:")); filtros.add(fechaInicio);
        filtros.add(new JLabel("Hasta:")); filtros.add(fechaFin);
        JButton consultar = new JButton("Consultar");
        filtros.add(consultar);

        JPanel centro = new JPanel(new BorderLayout(6, 6));
        centro.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));
        centro.add(filtros, BorderLayout.NORTH);
        tabla.setRowHeight(24);
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        centro.add(new JScrollPane(tabla), BorderLayout.CENTER);
        lblResumen.setFont(new Font("SansSerif", Font.BOLD, 14));
        lblResumen.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        centro.add(lblResumen, BorderLayout.SOUTH);
        add(centro, BorderLayout.CENTER);

        JPanel abajo = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 10));
        JButton pdf = new JButton("Generar PDF");
        abajo.add(pdf);
        add(abajo, BorderLayout.SOUTH);

        consultar.addActionListener(e -> consultarVentas());
        pdf.addActionListener(e -> generarPDF());
        consultarVentas();
    }

    private static JSpinner selectorFecha() {
        SpinnerDateModel model = new SpinnerDateModel(new Date(), null, null, java.util.Calendar.DAY_OF_MONTH);
        JSpinner spinner = new JSpinner(model);
        spinner.setEditor(new JSpinner.DateEditor(spinner, "dd/MM/yyyy"));
        spinner.setPreferredSize(new Dimension(115, 28));
        return spinner;
    }

    private void consultarVentas() {
        Date inicio = (Date) fechaInicio.getValue();
        Date fin = (Date) fechaFin.getValue();
        if (inicio.after(fin)) {
            JOptionPane.showMessageDialog(this, "La fecha inicial no puede ser posterior a la fecha final.",
                    "Rango inválido", JOptionPane.WARNING_MESSAGE);
            return;
        }
        java.sql.Date sqlInicio = new java.sql.Date(inicio.getTime());
        java.sql.Date sqlFin = new java.sql.Date(fin.getTime());
        String sql = "SELECT v.id_venta, v.fecha, v.total, v.id_usuario, u.nombre " +
                "FROM venta v JOIN usuario u ON u.id_usuario=v.id_usuario " +
                "WHERE v.fecha >= ? AND v.fecha < DATE_ADD(?, INTERVAL 1 DAY) " +
                "ORDER BY v.fecha DESC, v.id_venta DESC";
        try (Connection con = Conexion.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setDate(1, sqlInicio);
            ps.setDate(2, sqlFin);
            try (ResultSet rs = ps.executeQuery()) {
                ventasActuales.clear();
                modelo.setRowCount(0);
                totalActual = 0.0;
                while (rs.next()) {
                    java.sql.Timestamp ts = rs.getTimestamp("fecha");
                    LocalDateTime fecha = ts.toLocalDateTime();
                    Venta venta = new Venta(rs.getInt("id_venta"), fecha, rs.getDouble("total"),
                            rs.getInt("id_usuario"), rs.getString("nombre"));
                    ventasActuales.add(venta);
                    totalActual += venta.getTotal();
                    modelo.addRow(new Object[]{venta.getIdVenta(), fecha.format(formatoFecha),
                            venta.getNombreUsuario(), String.format(Locale.US, "$%.2f", venta.getTotal())});
                }
            }
            lblResumen.setText("Ventas: " + ventasActuales.size() + "     Total vendido: " +
                    String.format(Locale.US, "$%.2f", totalActual));
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "No se pudo consultar el reporte: " + ex.getMessage(),
                    "Error de base de datos", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void generarPDF() {
        if (ventasActuales.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No hay ventas para generar el PDF. Primero consulta un rango con resultados.",
                    "Sin datos", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Guardar reporte de ventas en PDF");
        chooser.setSelectedFile(new java.io.File("Reporte_Ventas.pdf"));
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        Path destino = chooser.getSelectedFile().toPath();
        if (!destino.toString().toLowerCase(Locale.ROOT).endsWith(".pdf")) {
            destino = java.nio.file.Paths.get(destino.toString() + ".pdf");
        }
        try {
            String contenido = crearContenidoPDF();
            escribirPDF(destino, contenido);
            JOptionPane.showMessageDialog(this, "PDF generado correctamente:\n" + destino.toAbsolutePath(),
                    "Reporte generado", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "No se pudo generar el PDF: " + ex.getMessage(),
                    "Error al generar PDF", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String crearContenidoPDF() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        StringBuilder s = new StringBuilder();
        s.append("LA GRAN FAMILIA").append('\n');
        s.append("REPORTE DE VENTAS").append('\n');
        s.append("Periodo: ").append(sdf.format((Date) fechaInicio.getValue())).append(" - ")
                .append(sdf.format((Date) fechaFin.getValue())).append('\n');
        s.append("Ventas registradas: ").append(ventasActuales.size()).append('\n');
        s.append("Total vendido: ").append(String.format(Locale.US, "$%.2f", totalActual)).append('\n');
        s.append("--------------------------------------------------------------------------").append('\n');
        s.append(String.format("%-8s %-18s %-27s %12s", "FOLIO", "FECHA", "EMPLEADO", "TOTAL")).append('\n');
        s.append("--------------------------------------------------------------------------").append('\n');
        for (Venta v : ventasActuales) {
            String empleado = v.getNombreUsuario() == null ? "" : v.getNombreUsuario();
            if (empleado.length() > 25) empleado = empleado.substring(0, 25);
            s.append(String.format(Locale.US, "%-8d %-18s %-27s %12s", v.getIdVenta(),
                    v.getFecha().format(formatoFecha), empleado,
                    String.format(Locale.US, "$%.2f", v.getTotal()))).append('\n');
        }
        return s.toString();
    }

    // Generador PDF básico de texto multipágina.
    private static void escribirPDF(Path destino, String texto) throws IOException {
        String[] lineas = texto.split("\\n", -1);
        final int lineasPorPagina = 62;
        List<byte[]> objetos = new ArrayList<>();
        int paginas = Math.max(1, (lineas.length + lineasPorPagina - 1) / lineasPorPagina);
        
        objetos.add(null);
        objetos.add(null);
        objetos.add("<< /Type /Font /Subtype /Type1 /BaseFont /Courier >>".getBytes(StandardCharsets.US_ASCII));
        List<Integer> idsPagina = new ArrayList<>();
        for (int i = 0; i < paginas; i++) {
            int idPagina = objetos.size() + 1;
            int idContenido = idPagina + 1;
            idsPagina.add(idPagina);
            objetos.add(("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 842] " +
                    "/Resources << /Font << /F1 3 0 R >> >> /Contents " + idContenido + " 0 R >>")
                    .getBytes(StandardCharsets.US_ASCII));
            StringBuilder stream = new StringBuilder("BT\n/F1 9 Tf\n45 800 Td\n12 TL\n");
            int desde = i * lineasPorPagina;
            int hasta = Math.min(lineas.length, desde + lineasPorPagina);
            for (int j = desde; j < hasta; j++) {
                stream.append('(').append(escaparPDF(lineas[j])).append(") Tj\nT*\n");
            }
            stream.append("ET");
            byte[] contenido = stream.toString().getBytes(StandardCharsets.ISO_8859_1);
            java.io.ByteArrayOutputStream objContenido = new java.io.ByteArrayOutputStream();
            objContenido.write(("<< /Length " + contenido.length + " >>\nstream\n").getBytes(StandardCharsets.US_ASCII));
            objContenido.write(contenido);
            objContenido.write("\nendstream".getBytes(StandardCharsets.US_ASCII));
            objetos.add(objContenido.toByteArray());
        }
        StringBuilder kids = new StringBuilder();
        for (Integer id : idsPagina) kids.append(id).append(" 0 R ");
        objetos.set(0, "<< /Type /Catalog /Pages 2 0 R >>".getBytes(StandardCharsets.US_ASCII));
        objetos.set(1, ("<< /Type /Pages /Kids [" + kids + "] /Count " + paginas + " >>").getBytes(StandardCharsets.US_ASCII));

        java.io.ByteArrayOutputStream pdf = new java.io.ByteArrayOutputStream();
        pdf.write("%PDF-1.4\n".getBytes(StandardCharsets.US_ASCII));
        List<Integer> offsets = new ArrayList<>(); offsets.add(0);
        for (int i = 0; i < objetos.size(); i++) {
            offsets.add(pdf.size());
            pdf.write(((i + 1) + " 0 obj\n").getBytes(StandardCharsets.US_ASCII));
            pdf.write(objetos.get(i));
            pdf.write("\nendobj\n".getBytes(StandardCharsets.US_ASCII));
        }
        int xref = pdf.size();
        pdf.write(("xref\n0 " + (objetos.size() + 1) + "\n0000000000 65535 f \n").getBytes(StandardCharsets.US_ASCII));
        for (int i = 1; i < offsets.size(); i++) {
            pdf.write(String.format(Locale.US, "%010d 00000 n \n", offsets.get(i)).getBytes(StandardCharsets.US_ASCII));
        }
        pdf.write(("trailer\n<< /Size " + (objetos.size() + 1) + " /Root 1 0 R >>\nstartxref\n" + xref + "\n%%EOF").getBytes(StandardCharsets.US_ASCII));
        Files.write(destino, pdf.toByteArray());
    }

    private static String escaparPDF(String texto) {
        return texto.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
                .replaceAll("[^\\x20-\\x7E]", "?");
    }
}
