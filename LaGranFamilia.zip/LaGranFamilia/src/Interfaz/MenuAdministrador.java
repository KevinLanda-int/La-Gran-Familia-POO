package Interfaz;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class MenuAdministrador extends JFrame {
    private final int idUsuario;
    private final String nombre;
    public MenuAdministrador() { this(1, "Administrador"); }
    public MenuAdministrador(String nombre) { this(1, nombre); }
    public MenuAdministrador(int idUsuario, String nombre) {
        this.idUsuario=idUsuario; this.nombre=nombre;
        setTitle("La Gran Familia - Menú administrador"); setSize(800, 590); setLocationRelativeTo(null); setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); setResizable(false);
        JPanel p=new JPanel(null); p.setBackground(new Color(255,248,225)); setContentPane(p);
        JPanel head=new JPanel(null); head.setBackground(new Color(255,193,7)); head.setBounds(0,0,784,100); p.add(head);
        JLabel title=new JLabel("LA GRAN FAMILIA",SwingConstants.CENTER); title.setFont(new Font("Serif",Font.BOLD,30)); title.setBounds(80,15,624,40); head.add(title);
        JLabel sub=new JLabel("MENÚ DE ADMINISTRADOR",SwingConstants.CENTER); sub.setFont(new Font("Serif",Font.BOLD,17)); sub.setBounds(80,55,624,28); head.add(sub);
        JLabel welcome=new JLabel("Bienvenido: "+nombre,SwingConstants.CENTER); welcome.setFont(new Font("Serif",Font.BOLD,18)); welcome.setBounds(20,110,744,35); p.add(welcome);
        JButton ventas=boton("Registrar venta"); ventas.setBounds(40,165,330,115); p.add(ventas);
        JButton productos=boton("Administrar productos"); productos.setBounds(410,165,330,115); p.add(productos);
        JButton historial=boton("Historial y detalles de ventas"); historial.setBounds(40,305,330,115); p.add(historial);
        JButton reporte=boton("Reporte de ventas"); reporte.setBounds(410,305,330,115); p.add(reporte);
        JButton salir=new JButton("Cerrar sesión"); salir.setBounds(260,455,260,45); p.add(salir);
        ventas.addActionListener(e->abrir(new Ventas(idUsuario)));
        productos.addActionListener(e->abrir(new InterfazProducto()));
        historial.addActionListener(e->abrir(new HistorialVentas()));
        reporte.addActionListener(e->abrir(new ReporteVentas()));
        salir.addActionListener(e->{ if(JOptionPane.showConfirmDialog(this,"¿Deseas cerrar la sesión?","Confirmar",JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION){new Login().setVisible(true);dispose();} });
    }
    private JButton boton(String t){ JButton b=new JButton(t); b.setFont(new Font("Serif",Font.BOLD,21)); b.setBackground(new Color(211,232,157)); return b; }
    private void abrir(JFrame ventana){ setVisible(false); ventana.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); ventana.addWindowListener(new WindowAdapter(){@Override public void windowClosed(WindowEvent e){setVisible(true);}}); ventana.setVisible(true); }
}
