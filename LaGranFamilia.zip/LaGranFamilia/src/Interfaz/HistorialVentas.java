package Interfaz;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.time.format.DateTimeFormatter;
import java.util.List;
import BD.VentaBD;
import Modelo.DetalleVenta;
import Modelo.Venta;

public class HistorialVentas extends JFrame {
    private final VentaBD ventaBD=new VentaBD();
    private final DefaultTableModel modelo=new DefaultTableModel(new Object[]{"Folio","Fecha","Usuario","Total"},0){@Override public boolean isCellEditable(int r,int c){return false;}};
    private final JTable tabla=new JTable(modelo);
    public HistorialVentas(){setTitle("La Gran Familia - Historial de ventas");setSize(760,470);setLocationRelativeTo(null);setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);setContentPane(new JPanel(new BorderLayout(8,8)));((JPanel)getContentPane()).setBorder(BorderFactory.createEmptyBorder(10,10,10,10));getContentPane().add(new JLabel("HISTORIAL DE VENTAS",SwingConstants.CENTER),BorderLayout.NORTH);getContentPane().add(new JScrollPane(tabla),BorderLayout.CENTER);JPanel abajo=new JPanel();JButton ver=new JButton("Ver detalle"),actualizar=new JButton("Actualizar");abajo.add(ver);abajo.add(actualizar);getContentPane().add(abajo,BorderLayout.SOUTH);ver.addActionListener(e->verDetalle());actualizar.addActionListener(e->cargar());cargar();}
    private void cargar(){try{modelo.setRowCount(0);List<Venta> ventas=ventaBD.consultarVentas();DateTimeFormatter f=DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");for(Venta v:ventas)modelo.addRow(new Object[]{v.getIdVenta(),v.getFecha().format(f),v.getNombreUsuario(),String.format(java.util.Locale.US,"$%.2f",v.getTotal())});}catch(SQLException ex){JOptionPane.showMessageDialog(this,"No se pudo consultar el historial: "+ex.getMessage());}}
    private void verDetalle(){int fila=tabla.getSelectedRow();if(fila<0){JOptionPane.showMessageDialog(this,"Selecciona una venta.");return;}int id=Integer.parseInt(modelo.getValueAt(fila,0).toString());try{List<DetalleVenta> detalles=ventaBD.consultarDetalles(id);StringBuilder s=new StringBuilder("DETALLE DE LA VENTA #").append(id).append("\n\n");for(DetalleVenta d:detalles)s.append(d.getNombreProducto()).append(" | Cantidad: ").append(d.getCantidad()).append(" | Precio: $").append(String.format(java.util.Locale.US,"%.2f",d.getPrecioUnitario())).append(" | Subtotal: $").append(String.format(java.util.Locale.US,"%.2f",d.getSubtotal())).append("\n");JTextArea area=new JTextArea(s.toString(),12,45);area.setEditable(false);JOptionPane.showMessageDialog(this,new JScrollPane(area),"Detalle de venta",JOptionPane.INFORMATION_MESSAGE);}catch(SQLException ex){JOptionPane.showMessageDialog(this,"No se pudo consultar el detalle: "+ex.getMessage());}}
}
