package Interfaz;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class MenuEmpleado extends JFrame {
    private final int idUsuario;
    private final String nombre;
    public MenuEmpleado(){this(2,"Empleado");}
    public MenuEmpleado(String nombre){this(2,nombre);}
    public MenuEmpleado(int idUsuario,String nombre){
        this.idUsuario=idUsuario; this.nombre=nombre;
        setTitle("La Gran Familia - Menú empleado"); setSize(760,520); setLocationRelativeTo(null); setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); setResizable(false);
        JPanel p=new JPanel(null); p.setBackground(new Color(255,248,225)); setContentPane(p);
        JPanel head=new JPanel(null); head.setBackground(new Color(255,193,7)); head.setBounds(0,0,744,95); p.add(head);
        JLabel title=new JLabel("LA GRAN FAMILIA",SwingConstants.CENTER); title.setFont(new Font("Serif",Font.BOLD,29)); title.setBounds(70,12,604,38); head.add(title);
        JLabel sub=new JLabel("MENÚ DE EMPLEADO",SwingConstants.CENTER); sub.setFont(new Font("Serif",Font.BOLD,17)); sub.setBounds(70,52,604,28); head.add(sub);
        JLabel welcome=new JLabel("Bienvenido: "+nombre,SwingConstants.CENTER); welcome.setFont(new Font("Serif",Font.BOLD,18)); welcome.setBounds(20,105,704,35); p.add(welcome);
        JButton ventas=boton("Registrar venta"); ventas.setBounds(35,165,330,120); p.add(ventas);
        JButton productos=boton("Consultar inventario"); productos.setBounds(395,165,330,120); p.add(productos);
        JButton historial=boton("Ventas recientes"); historial.setBounds(35,315,330,90); p.add(historial);
        JButton salir=new JButton("Cerrar sesión"); salir.setBounds(395,315,330,90); p.add(salir);
        ventas.addActionListener(e->abrir(new Ventas(idUsuario)));
        productos.addActionListener(e->abrir(new InterfazProducto(true)));
        historial.addActionListener(e->abrir(new HistorialVentas()));
        salir.addActionListener(e->{if(JOptionPane.showConfirmDialog(this,"¿Deseas cerrar la sesión?","Confirmar",JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION){new Login().setVisible(true);dispose();}});
    }
    private JButton boton(String t){JButton b=new JButton(t);b.setFont(new Font("Serif",Font.BOLD,22));b.setBackground(new Color(211,232,157));return b;}
    private void abrir(JFrame ventana){setVisible(false);ventana.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);ventana.addWindowListener(new WindowAdapter(){@Override public void windowClosed(WindowEvent e){setVisible(true);}});ventana.setVisible(true);}
}
