package Interfaz;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;
import Modelo.Producto;
import Servicios.InventarioServicio;

public class InterfazProducto extends JFrame {
    private final InventarioServicio inventario = new InventarioServicio();
    private final JTextField txtNombre=new JTextField(), txtPrecio=new JTextField(), txtStock=new JTextField();
    private final DefaultTableModel modelo=new DefaultTableModel(new Object[]{"ID","Nombre","Precio","Stock"},0){@Override public boolean isCellEditable(int r,int c){return false;}};
    private final JTable tabla=new JTable(modelo);
    private final boolean soloConsulta;

    public InterfazProducto(){this(false);}
    public InterfazProducto(boolean soloConsulta){
        this.soloConsulta=soloConsulta;
        setTitle("La Gran Familia - Productos");setSize(720,520);setLocationRelativeTo(null);setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);setResizable(false);
        JPanel p=new JPanel(null);p.setBackground(new Color(255,193,7));setContentPane(p);
        JLabel titulo=new JLabel("LA GRAN FAMILIA - INVENTARIO",SwingConstants.CENTER);titulo.setFont(new Font("Serif",Font.BOLD,23));titulo.setBounds(20,12,665,35);p.add(titulo);
        JLabel ln=new JLabel("Nombre:");ln.setBounds(25,65,90,25);p.add(ln);txtNombre.setBounds(115,65,230,27);p.add(txtNombre);
        JLabel lp=new JLabel("Precio:");lp.setBounds(25,102,90,25);p.add(lp);txtPrecio.setBounds(115,102,230,27);p.add(txtPrecio);
        JLabel ls=new JLabel("Stock:");ls.setBounds(25,139,90,25);p.add(ls);txtStock.setBounds(115,139,230,27);p.add(txtStock);
        JButton registrar=btn("Registrar"), modificar=btn("Modificar"), eliminar=btn("Eliminar"), consultar=btn("Actualizar"), limpiar=btn("Limpiar");
        registrar.setBounds(385,62,135,32);modificar.setBounds(535,62,145,32);eliminar.setBounds(385,102,135,32);consultar.setBounds(535,102,145,32);limpiar.setBounds(460,142,135,32);
        p.add(registrar);p.add(modificar);p.add(eliminar);p.add(consultar);p.add(limpiar);
        if(soloConsulta){txtNombre.setEditable(false);txtPrecio.setEditable(false);txtStock.setEditable(false);registrar.setVisible(false);modificar.setVisible(false);eliminar.setVisible(false);limpiar.setVisible(false);consultar.setBounds(460,102,145,32);}
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);p.add(new JScrollPane(tabla)).setBounds(25,200,655,250);
        tabla.getSelectionModel().addListSelectionListener(e->{if(!e.getValueIsAdjusting()&&tabla.getSelectedRow()>=0){int r=tabla.getSelectedRow();txtNombre.setText(modelo.getValueAt(r,1).toString());txtPrecio.setText(modelo.getValueAt(r,2).toString());txtStock.setText(modelo.getValueAt(r,3).toString());}});
        registrar.addActionListener(e->ejecutar(0));modificar.addActionListener(e->ejecutar(1));eliminar.addActionListener(e->borrar());consultar.addActionListener(e->cargarTabla());limpiar.addActionListener(e->limpiar());
        cargarTabla();
    }
    private JButton btn(String t){JButton b=new JButton(t);b.setBackground(new Color(204,204,0));return b;}
    private void ejecutar(int tipo){try{String nombre=txtNombre.getText().trim();double precio=Double.parseDouble(txtPrecio.getText().trim().replace(',','.'));int stock=Integer.parseInt(txtStock.getText().trim());boolean ok;if(tipo==0)ok=inventario.registrarProducto(nombre,precio,stock);else{int r=tabla.getSelectedRow();if(r<0){mensaje("Selecciona un producto de la tabla.");return;}int id=Integer.parseInt(modelo.getValueAt(r,0).toString());ok=inventario.modificarProducto(id,nombre,precio,stock);}if(ok){mensaje(tipo==0?"Producto registrado correctamente.":"Producto modificado correctamente.");limpiar();cargarTabla();}else mensaje("No se realizó la operación.");}catch(NumberFormatException ex){mensaje("Escribe un precio válido y un stock entero.");}catch(IllegalArgumentException ex){mensaje(ex.getMessage());}catch(SQLException ex){mensaje("Error de base de datos: "+ex.getMessage());}}
    private void borrar(){int r=tabla.getSelectedRow();if(r<0){mensaje("Selecciona un producto.");return;}int id=Integer.parseInt(modelo.getValueAt(r,0).toString());if(JOptionPane.showConfirmDialog(this,"¿Eliminar el producto seleccionado?","Confirmar",JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION)return;try{if(inventario.eliminarProducto(id)){mensaje("Producto eliminado.");limpiar();cargarTabla();}else mensaje("No se pudo eliminar el producto. Puede tener ventas asociadas.");}catch(SQLException ex){mensaje("No se pudo eliminar: "+ex.getMessage());}}
    private void cargarTabla(){try{List<Producto> productos=inventario.consultarProductos();modelo.setRowCount(0);for(Producto x:productos)modelo.addRow(new Object[]{x.getId_producto(),x.getNombre(),x.getPrecio(),x.getStock()});}catch(SQLException ex){mensaje("No se pudo consultar el inventario: "+ex.getMessage());}}
    private void limpiar(){txtNombre.setText("");txtPrecio.setText("");txtStock.setText("");tabla.clearSelection();}
    private void mensaje(String m){JOptionPane.showMessageDialog(this,m);}
}
