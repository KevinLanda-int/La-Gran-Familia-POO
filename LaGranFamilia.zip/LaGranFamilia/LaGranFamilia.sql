CREATE DATABASE IF NOT EXISTS LaGranFamilia CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE LaGranFamilia;

CREATE TABLE IF NOT EXISTS usuario (
  id_usuario INT NOT NULL AUTO_INCREMENT,
  nombre VARCHAR(100) NOT NULL,
  usuario VARCHAR(50) NOT NULL UNIQUE,
  contrasena VARCHAR(100) NOT NULL,
  rol VARCHAR(20) NOT NULL,
  PRIMARY KEY (id_usuario)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS producto (
  id_producto INT NOT NULL AUTO_INCREMENT,
  nombre VARCHAR(100) NOT NULL,
  precio DECIMAL(10,2) NOT NULL,
  stock INT NOT NULL,
  PRIMARY KEY (id_producto),
  CONSTRAINT chk_producto_precio CHECK (precio > 0),
  CONSTRAINT chk_producto_stock CHECK (stock >= 0)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS venta (
  id_venta INT NOT NULL AUTO_INCREMENT,
  fecha DATETIME NOT NULL,
  total DECIMAL(10,2) NOT NULL,
  id_usuario INT NOT NULL,
  PRIMARY KEY (id_venta),
  KEY idx_venta_usuario (id_usuario),
  CONSTRAINT fk_venta_usuario FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS detalle_venta (
  id_detalle INT NOT NULL AUTO_INCREMENT,
  id_venta INT NOT NULL,
  id_producto INT NOT NULL,
  cantidad INT NOT NULL,
  precio_unitario DECIMAL(10,2) NOT NULL,
  subtotal DECIMAL(10,2) NOT NULL,
  PRIMARY KEY (id_detalle),
  KEY idx_detalle_venta (id_venta),
  KEY idx_detalle_producto (id_producto),
  CONSTRAINT fk_detalle_venta FOREIGN KEY (id_venta) REFERENCES venta(id_venta),
  CONSTRAINT fk_detalle_producto FOREIGN KEY (id_producto) REFERENCES producto(id_producto),
  CONSTRAINT chk_detalle_cantidad CHECK (cantidad > 0)
) ENGINE=InnoDB;

-- Usuarios de prueba. Cambia estas contraseñas después de comprobar el sistema.
INSERT INTO usuario (nombre, usuario, contrasena, rol)
VALUES ('Administrador General', 'admin', '1234', 'Administrador')
ON DUPLICATE KEY UPDATE nombre=VALUES(nombre), rol=VALUES(rol);

INSERT INTO usuario (nombre, usuario, contrasena, rol)
VALUES ('Empleado 1', 'empleado1', '1234', 'Empleado')
ON DUPLICATE KEY UPDATE nombre=VALUES(nombre), rol=VALUES(rol);

-- Ejemplos opcionales de productos (no se insertan automáticamente):
-- INSERT INTO producto (nombre, precio, stock) VALUES ('Chetos', 20.00, 65);
