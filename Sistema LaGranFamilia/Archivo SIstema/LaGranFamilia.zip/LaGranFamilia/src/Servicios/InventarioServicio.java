package Servicios;

import java.util.ArrayList;

import BD.ProductoBD;
import Modelo.Producto;

public class InventarioServicio {

    private ProductoBD productoBD;

    public InventarioServicio() {
        productoBD = new ProductoBD();
    }

    public void registrarProducto(String nombre, double precio, int stock) {
        Producto producto = new Producto(nombre, precio, stock);

        productoBD.registrarProducto(producto);
    }

    public ArrayList<Producto> consultarProductos() {

        return productoBD.consultarProductos();
    }

public boolean modificarProducto(int id, String nombre, double precio, int stock) {

    if (id <= 0 || nombre == null || nombre.trim().isEmpty()
            || precio <= 0 || stock < 0) {
        return false;
    }

    Producto producto = new Producto(id, nombre.trim(), precio, stock);

    return productoBD.modificarProducto(producto);
}

public boolean eliminarProducto(int id) {

    if (id <= 0) {
        return false;
    }

    return productoBD.eliminarProducto(id);
}

}