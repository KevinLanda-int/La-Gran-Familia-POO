package Servicios;
import java.util.Scanner;

public class Programa {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
        GestorVentas gestor = new GestorVentas();
        int opcion;

        do {
            System.out.println("=== TIENDA MISCELANEA ===");
            System.out.println("1. Realizar venta");
            System.out.println("2. Consultar venta");
            System.out.println("3. Salir");
            System.out.print("Selecciona una opcion: ");
            System.out.println("=========================");

            opcion = s.nextInt();
            s.nextLine();

            switch (opcion) {

                case 1:
                    System.out.print("Nombre del producto: ");
                    String producto = s.nextLine();

                    System.out.print("Cantidad: ");
                    int cantidad = s.nextInt();

                    System.out.print("Precio unitario: ");
                    double precio = s.nextDouble();

                    gestor.realizarVenta(producto, cantidad, precio);
                    break;

                case 2:
                    System.out.print("Ingresa el folio de la venta: ");
                    int folio = s.nextInt();

                    gestor.consultarVenta(folio);
                    break;

                case 3:
                    System.out.println("Saliendo del sistema...");
                    break;

                default:
                    System.out.println("Opcion no valida.");
            }

        } while (opcion != 3);
        s.close();
    }
	}

