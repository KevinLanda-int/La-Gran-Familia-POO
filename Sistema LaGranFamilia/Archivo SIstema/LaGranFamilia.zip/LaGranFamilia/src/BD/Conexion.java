package BD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {

    private static final String url = "jdbc:mysql://localhost:3306/LaGranFamilia";
    private static final String usuario = "root";
    private static final String password = "root";

    public static Connection conectar() throws SQLException {
        return DriverManager.getConnection(url, usuario, password);
    }
}