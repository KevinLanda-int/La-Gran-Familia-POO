package BD;

public class VentaBD {

}
