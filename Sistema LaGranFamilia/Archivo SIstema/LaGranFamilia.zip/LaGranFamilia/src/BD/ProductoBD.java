package BD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import Modelo.Producto;

public class ProductoBD {

    public void registrarProducto(Producto producto) {

        String sql = "INSERT INTO producto (nombre, precio, stock) VALUES (?, ?, ?)";

        try (Connection conexion = Conexion.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {

            sentencia.setString(1, producto.getNombre());
            sentencia.setDouble(2, producto.getPrecio());
            sentencia.setInt(3, producto.getStock());

            sentencia.executeUpdate();

            System.out.println("Producto registrado correctamente.");

        } catch (Exception e) {
            System.out.println("Error al registrar producto: " + e.getMessage());
        }
    }

    public ArrayList<Producto> consultarProductos() {

        ArrayList<Producto> productos = new ArrayList<>();

        String sql = "SELECT id_producto, nombre, precio, stock FROM producto";

        try (Connection conexion = Conexion.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql);
             ResultSet resultado = sentencia.executeQuery()) {

            while (resultado.next()) {

                Producto producto = new Producto(
                    resultado.getInt("id_producto"),
                    resultado.getString("nombre"),
                    resultado.getDouble("precio"),
                    resultado.getInt("stock")
                );

                productos.add(producto);
            }

        } catch (Exception e) {
            System.out.println("Error al consultar productos: " + e.getMessage());
        }

        return productos;
    }
}