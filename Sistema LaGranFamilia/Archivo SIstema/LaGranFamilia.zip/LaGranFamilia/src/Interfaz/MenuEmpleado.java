package Interfaz;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

public class MenuEmpleado extends JFrame {

    private static final long serialVersionUID = 1L;

    private JPanel contentPane;

    private final Color AMARILLO = new Color(255, 193, 7);
    private final Color CREMA = new Color(255, 248, 225);
    private final Color VERDE = new Color(211, 232, 157);
    private final Color VERDE_HOVER = new Color(190, 218, 125);
    private final Color OSCURO = new Color(45, 45, 45);
    private final Color ROJO = new Color(153, 45, 45);

    public MenuEmpleado() {
        this("Empleado");
    }

    public MenuEmpleado(String nombreEmpleado) {

        setTitle("Menu Principal");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 800, 620);
        setLocationRelativeTo(null);
        setResizable(false);

        contentPane = new JPanel();
        contentPane.setBackground(CREMA);
        contentPane.setLayout(null);
        setContentPane(contentPane);

        // Encabezado
        JPanel panelEncabezado = new JPanel();
        panelEncabezado.setBackground(AMARILLO);
        panelEncabezado.setLayout(null);
        panelEncabezado.setBounds(0, 0, 784, 105);
        contentPane.add(panelEncabezado);

        JLabel lblTitulo = new JLabel("LA GRAN FAMILIA");
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Stencil", Font.BOLD, 32));
        lblTitulo.setBounds(100, 15, 584, 42);
        panelEncabezado.add(lblTitulo);

        JLabel lblSubtitulo = new JLabel("MENU PRINCIPAL");
        lblSubtitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblSubtitulo.setFont(new Font("Serif", Font.BOLD, 18));
        lblSubtitulo.setBounds(100, 59, 584, 30);
        panelEncabezado.add(lblSubtitulo);

        // Bienvenida
        JLabel lblBienvenida = new JLabel(
            "BIENVENIDO EMPLEADO: " + nombreEmpleado
        );
        lblBienvenida.setHorizontalAlignment(SwingConstants.CENTER);
        lblBienvenida.setFont(new Font("Serif", Font.BOLD, 18));
        lblBienvenida.setBounds(20, 115, 744, 35);
        contentPane.add(lblBienvenida);

        // Boton Ventas
        JButton btnVentas = new JButton("Ventas");
        btnVentas.setFont(new Font("Serif", Font.BOLD, 28));
        btnVentas.setForeground(OSCURO);
        btnVentas.setBackground(VERDE);
        btnVentas.setFocusPainted(false);
        btnVentas.setCursor(
            Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)
        );
        btnVentas.setBorder(BorderFactory.createLineBorder(
            new Color(180, 190, 130)
        ));
        btnVentas.setBounds(40, 180, 340, 145);
        contentPane.add(btnVentas);

        btnVentas.addActionListener(e ->
            JOptionPane.showMessageDialog(
                this,
                "La interfaz de ventas se conectara posteriormente.",
                "Ventas",
                JOptionPane.INFORMATION_MESSAGE
            )
        );

        btnVentas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) {
                btnVentas.setBackground(VERDE_HOVER);
            }

            public void mouseExited(java.awt.event.MouseEvent e) {
                btnVentas.setBackground(VERDE);
            }
        });

        // Boton Productos
        JButton btnProductos = new JButton("Productos");
        btnProductos.setFont(new Font("Serif", Font.BOLD, 28));
        btnProductos.setForeground(OSCURO);
        btnProductos.setBackground(VERDE);
        btnProductos.setFocusPainted(false);
        btnProductos.setCursor(
            Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)
        );
        btnProductos.setBorder(BorderFactory.createLineBorder(
            new Color(180, 190, 130)
        ));
        btnProductos.setBounds(400, 180, 340, 145);
        contentPane.add(btnProductos);

        btnProductos.addActionListener(e ->
            JOptionPane.showMessageDialog(
                this,
                "La interfaz de productos se conectara posteriormente.",
                "Productos",
                JOptionPane.INFORMATION_MESSAGE
            )
        );

        btnProductos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) {
                btnProductos.setBackground(VERDE_HOVER);
            }

            public void mouseExited(java.awt.event.MouseEvent e) {
                btnProductos.setBackground(VERDE);
            }
        });

        // Boton Ventas recientes
        JButton btnRecientes = new JButton("Ventas recientes");
        btnRecientes.setFont(new Font("Serif", Font.BOLD, 26));
        btnRecientes.setForeground(OSCURO);
        btnRecientes.setBackground(new Color(255, 224, 102));
        btnRecientes.setFocusPainted(false);
        btnRecientes.setCursor(
            Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)
        );
        btnRecientes.setBorder(BorderFactory.createLineBorder(
            new Color(210, 180, 70)
        ));
        btnRecientes.setBounds(40, 350, 700, 80);
        contentPane.add(btnRecientes);

        btnRecientes.addActionListener(e ->
            JOptionPane.showMessageDialog(
                this,
                "Aqui se mostraran las ventas recientes.",
                "Ventas recientes",
                JOptionPane.INFORMATION_MESSAGE
            )
        );

        // Boton Salir
        JButton btnSalir = new JButton("Salir");
        btnSalir.setFont(new Font("Serif", Font.BOLD, 26));
        btnSalir.setForeground(ROJO);
        btnSalir.setBackground(VERDE);
        btnSalir.setFocusPainted(false);
        btnSalir.setCursor(
            Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)
        );
        btnSalir.setBorder(BorderFactory.createLineBorder(
            new Color(180, 190, 130)
        ));
        btnSalir.setBounds(220, 455, 340, 85);
        contentPane.add(btnSalir);

        btnSalir.addActionListener(e -> {

            int opcion = JOptionPane.showConfirmDialog(
                this,
                "¿Deseas cerrar la sesion?",
                "Confirmar salida",
                JOptionPane.YES_NO_OPTION
            );

            if (opcion == JOptionPane.YES_OPTION) {
                Login login = new Login();
                login.setVisible(true);
                dispose();
            }
        });

        btnSalir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) {
                btnSalir.setBackground(VERDE_HOVER);
            }

            public void mouseExited(java.awt.event.MouseEvent e) {
                btnSalir.setBackground(VERDE);
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MenuEmpleado menu = new MenuEmpleado();
            menu.setVisible(true);
        });
    }
}
