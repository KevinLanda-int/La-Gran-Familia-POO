package Interfaz;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

public class MenuAdministrador extends JFrame {

    private static final long serialVersionUID = 1L;

    private JPanel contentPane;

    private final Color AMARILLO = new Color(255, 193, 7);
    private final Color CREMA = new Color(255, 248, 225);
    private final Color VERDE = new Color(211, 232, 157);
    private final Color VERDE_HOVER = new Color(190, 218, 125);
    private final Color OSCURO = new Color(45, 45, 45);
    private final Color ROJO = new Color(153, 45, 45);

    public MenuAdministrador() {
        this("Administrador");
    }

    public MenuAdministrador(String nombreAdmin) {

        setTitle("Menu Principal");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 850, 650);
        setLocationRelativeTo(null);
        setResizable(false);

        contentPane = new JPanel();
        contentPane.setBackground(CREMA);
        contentPane.setLayout(null);
        setContentPane(contentPane);

        // Encabezado
        JPanel panelEncabezado = new JPanel();
        panelEncabezado.setBackground(AMARILLO);
        panelEncabezado.setLayout(null);
        panelEncabezado.setBounds(0, 0, 834, 105);
        contentPane.add(panelEncabezado);

        JLabel lblTitulo = new JLabel("LA GRAN FAMILIA");
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Stencil", Font.BOLD, 32));
        lblTitulo.setBounds(100, 15, 634, 42);
        panelEncabezado.add(lblTitulo);

        JLabel lblSubtitulo = new JLabel("MENU PRINCIPAL");
        lblSubtitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblSubtitulo.setFont(new Font("Serif", Font.BOLD, 18));
        lblSubtitulo.setBounds(100, 59, 634, 30);
        panelEncabezado.add(lblSubtitulo);

        // Bienvenida
        JLabel lblBienvenida = new JLabel(
            "BIENVENIDO ADMINISTRADOR: " + nombreAdmin
        );
        lblBienvenida.setHorizontalAlignment(SwingConstants.CENTER);
        lblBienvenida.setFont(new Font("Serif", Font.BOLD, 18));
        lblBienvenida.setBounds(25, 115, 784, 35);
        contentPane.add(lblBienvenida);

        // Boton Ventas
        JButton btnVentas = new JButton("Ventas");
        btnVentas.setFont(new Font("Serif", Font.BOLD, 28));
        btnVentas.setForeground(OSCURO);
        btnVentas.setBackground(VERDE);
        btnVentas.setFocusPainted(false);
        btnVentas.setCursor(
            Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)
        );
        btnVentas.setBorder(BorderFactory.createLineBorder(
            new Color(180, 190, 130)
        ));
        btnVentas.setBounds(45, 175, 355, 145);
        contentPane.add(btnVentas);

        btnVentas.addActionListener(e ->
            JOptionPane.showMessageDialog(
                this,
                "La interfaz de ventas se conectara posteriormente.",
                "Ventas",
                JOptionPane.INFORMATION_MESSAGE
            )
        );

        btnVentas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) {
                btnVentas.setBackground(VERDE_HOVER);
            }

            public void mouseExited(java.awt.event.MouseEvent e) {
                btnVentas.setBackground(VERDE);
            }
        });

        // Boton Detalle de ventas
        JButton btnDetalleVentas = new JButton("Detalle de ventas");
        btnDetalleVentas.setFont(new Font("Serif", Font.BOLD, 26));
        btnDetalleVentas.setForeground(OSCURO);
        btnDetalleVentas.setBackground(VERDE);
        btnDetalleVentas.setFocusPainted(false);
        btnDetalleVentas.setCursor(
            Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)
        );
        btnDetalleVentas.setBorder(BorderFactory.createLineBorder(
            new Color(180, 190, 130)
        ));
        btnDetalleVentas.setBounds(420, 175, 355, 145);
        contentPane.add(btnDetalleVentas);

        btnDetalleVentas.addActionListener(e ->
            JOptionPane.showMessageDialog(
                this,
                "Aqui se podran consultar los detalles de las ventas.",
                "Detalle de ventas",
                JOptionPane.INFORMATION_MESSAGE
            )
        );

        btnDetalleVentas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) {
                btnDetalleVentas.setBackground(VERDE_HOVER);
            }

            public void mouseExited(java.awt.event.MouseEvent e) {
                btnDetalleVentas.setBackground(VERDE);
            }
        });

        // Boton Productos
        JButton btnProductos = new JButton("Productos");
        btnProductos.setFont(new Font("Serif", Font.BOLD, 28));
        btnProductos.setForeground(OSCURO);
        btnProductos.setBackground(VERDE);
        btnProductos.setFocusPainted(false);
        btnProductos.setCursor(
            Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)
        );
        btnProductos.setBorder(BorderFactory.createLineBorder(
            new Color(180, 190, 130)
        ));
        btnProductos.setBounds(45, 340, 355, 145);
        contentPane.add(btnProductos);

        btnProductos.addActionListener(e ->
            JOptionPane.showMessageDialog(
                this,
                "La interfaz de productos se conectara posteriormente.",
                "Productos",
                JOptionPane.INFORMATION_MESSAGE
            )
        );

        btnProductos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) {
                btnProductos.setBackground(VERDE_HOVER);
            }

            public void mouseExited(java.awt.event.MouseEvent e) {
                btnProductos.setBackground(VERDE);
            }
        });

        // Boton Salir
        JButton btnSalir = new JButton("Salir");
        btnSalir.setFont(new Font("Serif", Font.BOLD, 28));
        btnSalir.setForeground(ROJO);
        btnSalir.setBackground(VERDE);
        btnSalir.setFocusPainted(false);
        btnSalir.setCursor(
            Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)
        );
        btnSalir.setBorder(BorderFactory.createLineBorder(
            new Color(180, 190, 130)
        ));
        btnSalir.setBounds(420, 340, 355, 145);
        contentPane.add(btnSalir);

        btnSalir.addActionListener(e -> {

            int opcion = JOptionPane.showConfirmDialog(
                this,
                "¿Deseas cerrar la sesion?",
                "Confirmar salida",
                JOptionPane.YES_NO_OPTION
            );

            if (opcion == JOptionPane.YES_OPTION) {
                Login login = new Login();
                login.setVisible(true);
                dispose();
            }
        });

        btnSalir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) {
                btnSalir.setBackground(VERDE_HOVER);
            }

            public void mouseExited(java.awt.event.MouseEvent e) {
                btnSalir.setBackground(VERDE);
            }
        });

        // Boton Reporte
        JButton btnReporte = new JButton("Reporte de ventas ");
        btnReporte.setFont(new Font("Serif", Font.BOLD, 21));
        btnReporte.setForeground(OSCURO);
        btnReporte.setBackground(new Color(255, 224, 102));
        btnReporte.setFocusPainted(false);
        btnReporte.setCursor(
            Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)
        );
        btnReporte.setBorder(BorderFactory.createLineBorder(
            new Color(210, 180, 70)
        ));
        btnReporte.setBounds(45, 505, 730, 75);
        contentPane.add(btnReporte);

        btnReporte.addActionListener(e ->
            JOptionPane.showMessageDialog(
                this,
                "El reporte de ventas se implementara posteriormente.",
                "Reporte de ventas",
                JOptionPane.INFORMATION_MESSAGE
            )
        );
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MenuAdministrador menu = new MenuAdministrador();
            menu.setVisible(true);
        });
    }
}
