/**
 * 
 */
/**
 * 
 */
module LaGranFamilia {
	requires java.desktop;
	requires java.sql;
}