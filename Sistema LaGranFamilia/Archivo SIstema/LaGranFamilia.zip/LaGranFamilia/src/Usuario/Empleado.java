package Usuario;

public class Empleado {

}
