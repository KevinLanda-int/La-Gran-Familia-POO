package Principal;

import java.util.ArrayList;
import java.util.Scanner;

import Modelo.Producto;
import Servicios.InventarioServicio;

public class principal {

    public static void main(String[] args) {

        Scanner leer = new Scanner(System.in);

        InventarioServicio inventario = new InventarioServicio();

        int opcion;

        do {

            System.out.println("\n===== LA GRAN FAMILIA =====");
            System.out.println("1. Registrar producto");
            System.out.println("2. Consultar productos");
            System.out.println("3. Salir");
            System.out.print("Seleccione una opcion: ");

            opcion = leer.nextInt();
            leer.nextLine();

            switch (opcion) {

                case 1:

                    System.out.print("Nombre del producto: ");
                    String nombre = leer.nextLine();

                    System.out.print("Precio: ");
                    double precio = leer.nextDouble();

                    System.out.print("Stock: ");
                    int stock = leer.nextInt();

                    inventario.registrarProducto(nombre, precio, stock);

                    break;

                case 2:

                    ArrayList<Producto> productos = inventario.consultarProductos();

                    System.out.println("\n===== PRODUCTOS ======");

                    if (productos.isEmpty()) {

                        System.out.println("No hay productos registrados.");

                    } else {

                        for (Producto producto : productos) {

                            System.out.println("ID: " + producto.getId_producto());
                            System.out.println("Nombre: " + producto.getNombre());
                            System.out.println("Precio: $" + producto.getPrecio());
                            System.out.println("Stock: " + producto.getStock());
                            System.out.println("_____________________");
                        }
                    }

                    break;

                case 3:

                    System.out.println("Programa finalizado.");

                    break;

                default:

                    System.out.println("Opcion no valida.");
            }

        } while (opcion != 3);

        leer.close();
    }
}