package Interfaz;

import java.awt.Color;
import java.awt.Font;
import javax.swing.UIManager;
import javax.swing.BorderFactory;

public final class DialogosEstilo {
    private static final Color AMARILLO = new Color(255, 193, 7);
    private static final Color VERDE = new Color(211, 232, 157);
    private static final Color OSCURO = new Color(45, 45, 45);
    private static final Color CREMA = new Color(255, 248, 225);

    private DialogosEstilo() {
    }

    public static void aplicar() {
        Font texto = new Font("Segoe UI", Font.BOLD, 14);
        Font botones = new Font("Segoe UI", Font.BOLD, 13);

        UIManager.put("OptionPane.messageFont", texto);
        UIManager.put("OptionPane.buttonFont", botones);
        UIManager.put("OptionPane.background", CREMA);
        UIManager.put("Panel.background", CREMA);
        UIManager.put("OptionPane.messageForeground", OSCURO);
        UIManager.put("OptionPane.border", BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(AMARILLO, 2),
            BorderFactory.createEmptyBorder(10, 12, 10, 12)
        ));
        UIManager.put("Button.background", AMARILLO);
        UIManager.put("Button.foreground", OSCURO);
        UIManager.put("Button.font", botones);
        UIManager.put("Button.focusPainted", Boolean.FALSE);
        UIManager.put("Button.border", BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(205, 160, 0)),
            BorderFactory.createEmptyBorder(5, 14, 5, 14)
        ));
        UIManager.put("OptionPane.yesButtonText", "Sí");
        UIManager.put("OptionPane.noButtonText", "No");
        UIManager.put("OptionPane.cancelButtonText", "Cancelar");
        UIManager.put("OptionPane.okButtonText", "Aceptar");
    }
}
