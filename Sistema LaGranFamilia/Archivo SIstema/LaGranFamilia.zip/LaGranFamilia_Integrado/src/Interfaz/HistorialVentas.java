package Interfaz;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.time.format.DateTimeFormatter;
import java.util.List;
import BD.VentaBD;
import Modelo.DetalleVenta;
import Modelo.Venta;

public class HistorialVentas extends JFrame {
    private final VentaBD ventaBD = new VentaBD();
    private final Color amarillo = new Color(255, 193, 7);
    private final Color crema = new Color(255, 248, 225);
    private final Color verde = new Color(211, 232, 157);
    private final Color texto = new Color(45, 45, 45);
    private final DefaultTableModel modelo = new DefaultTableModel(
        new Object[]{"Folio", "Fecha", "Usuario", "Total"}, 0) {
        @Override public boolean isCellEditable(int fila, int columna) { return false; }
    };
    private final JTable tabla = new JTable(modelo);

    public HistorialVentas() {
        IconoSistema.aplicar(this);
        setTitle("La Gran Familia - Historial de ventas");
        setSize(900, 560);
        setMinimumSize(new Dimension(760, 460));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(true);
        setLayout(new BorderLayout(0, 0));
        getContentPane().setBackground(crema);

        JPanel encabezado = new JPanel(new BorderLayout());
        encabezado.setBackground(amarillo);
        encabezado.setBorder(BorderFactory.createEmptyBorder(16, 22, 16, 22));
        JLabel titulo = new JLabel("Historial de ventas");
        titulo.setForeground(texto);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 22));
        encabezado.add(titulo, BorderLayout.WEST);
        add(encabezado, BorderLayout.NORTH);

        JPanel centro = new JPanel(new BorderLayout());
        centro.setBackground(crema);
        centro.setBorder(BorderFactory.createEmptyBorder(16, 18, 12, 18));
        tabla.setRowHeight(28);
        tabla.setFont(new Font("SansSerif", Font.PLAIN, 13));
        tabla.setForeground(texto);
        tabla.setSelectionBackground(new Color(255, 224, 130));
        tabla.setSelectionForeground(texto);
        tabla.setGridColor(new Color(230, 220, 190));
        tabla.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 13));
        tabla.getTableHeader().setBackground(new Color(255, 248, 225));
        tabla.getTableHeader().setForeground(texto);
        tabla.setFillsViewportHeight(true);
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(225, 213, 175)));
        centro.add(scroll, BorderLayout.CENTER);
        add(centro, BorderLayout.CENTER);

        JPanel abajo = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 12));
        abajo.setBackground(crema);
        JButton ver = crearBoton("Ver detalle", verde);
        JButton actualizar = crearBoton("Actualizar", Color.WHITE);
        JButton regresar = crearBoton("Regresar al menú", amarillo);
        abajo.add(ver);
        abajo.add(actualizar);
        abajo.add(regresar);
        add(abajo, BorderLayout.SOUTH);

        ver.addActionListener(e -> verDetalle());
        actualizar.addActionListener(e -> cargar());
        regresar.addActionListener(e -> dispose());
        cargar();
    }

    private JButton crearBoton(String nombre, Color fondo) {
        JButton boton = new JButton(nombre);
        boton.setFont(new Font("SansSerif", Font.BOLD, 13));
        boton.setForeground(texto);
        boton.setBackground(fondo);
        boton.setFocusPainted(false);
        boton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        boton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(210, 190, 130)),
            BorderFactory.createEmptyBorder(8, 16, 8, 16)));
        return boton;
    }

    private void cargar() {
        try {
            modelo.setRowCount(0);
            List<Venta> ventas = ventaBD.consultarVentas();
            DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
            for (Venta venta : ventas) {
                modelo.addRow(new Object[]{venta.getIdVenta(),
                    venta.getFecha().format(formato), venta.getNombreUsuario(),
                    String.format(java.util.Locale.US, "$%.2f", venta.getTotal())});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                "No se pudo consultar el historial: " + ex.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void verDetalle() {
        int fila = tabla.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(this, "Selecciona una venta.");
            return;
        }
        int id = Integer.parseInt(modelo.getValueAt(fila, 0).toString());
        try {
            List<DetalleVenta> detalles = ventaBD.consultarDetalles(id);
            StringBuilder contenido = new StringBuilder("DETALLE DE LA VENTA #")
                .append(id).append("\n\n");
            for (DetalleVenta detalle : detalles) {
                contenido.append(detalle.getNombreProducto())
                    .append(" | Cantidad: ").append(detalle.getCantidad())
                    .append(" | Precio: $")
                    .append(String.format(java.util.Locale.US, "%.2f", detalle.getPrecioUnitario()))
                    .append(" | Subtotal: $")
                    .append(String.format(java.util.Locale.US, "%.2f", detalle.getSubtotal()))
                    .append("\n");
            }
            JTextArea area = new JTextArea(contenido.toString(), 12, 45);
            area.setEditable(false);
            area.setFont(new Font("Monospaced", Font.PLAIN, 13));
            area.setBackground(crema);
            area.setForeground(texto);
            JOptionPane.showMessageDialog(this, new JScrollPane(area),
                "Detalle de venta", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                "No se pudo consultar el detalle: " + ex.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
