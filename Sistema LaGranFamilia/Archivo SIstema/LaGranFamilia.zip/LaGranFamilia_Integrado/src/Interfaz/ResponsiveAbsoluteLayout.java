package Interfaz;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.util.IdentityHashMap;
import java.util.Map;
import javax.swing.SwingUtilities;

final class ResponsiveAbsoluteLayout {
    private ResponsiveAbsoluteLayout() { }

    static void attach(Container container, Dimension baseSize) {
        if (container == null || container.getLayout() != null) return;
        int baseWidth = Math.max(1, baseSize.width);
        int baseHeight = Math.max(1, baseSize.height);
        Map<Component, Rectangle> original = new IdentityHashMap<>();
        for (Component child : container.getComponents()) {
            original.put(child, child.getBounds());
            if (child instanceof Container) {
                Container nested = (Container) child;
                if (nested.getLayout() == null) {
                    Rectangle b = child.getBounds();
                    attach(nested, new Dimension(Math.max(1, b.width), Math.max(1, b.height)));
                }
            }
        }
        container.addComponentListener(new ComponentAdapter() {
            @Override public void componentResized(ComponentEvent event) {
                int width = Math.max(1, container.getWidth());
                int height = Math.max(1, container.getHeight());
                double sx = width / (double) baseWidth;
                double sy = height / (double) baseHeight;
                for (Map.Entry<Component, Rectangle> entry : original.entrySet()) {
                    Rectangle b = entry.getValue();
                    entry.getKey().setBounds(
                        (int) Math.round(b.x * sx),
                        (int) Math.round(b.y * sy),
                        Math.max(1, (int) Math.round(b.width * sx)),
                        Math.max(1, (int) Math.round(b.height * sy))
                    );
                }
            }
        });
    }
}
