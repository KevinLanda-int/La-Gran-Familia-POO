package Interfaz;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class MenuEmpleado extends JFrame {
    private final int idUsuario;
    private final String nombre;
    public MenuEmpleado(){this(2,"Empleado");}
    public MenuEmpleado(String nombre){this(2,nombre);}
    public MenuEmpleado(int idUsuario,String nombre){
        IconoSistema.aplicar(this);
        this.idUsuario=idUsuario; this.nombre=nombre;
        setTitle("La Gran Familia - Menú empleado"); setSize(760,520); setMinimumSize(new Dimension(650, 450)); setLocationRelativeTo(null); setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); setResizable(true);
        JPanel p=new JPanel(null); p.setBackground(new Color(255,248,225)); setContentPane(p);
        ResponsiveAbsoluteLayout.attach(p, new Dimension(744, 484));
        JPanel head=new JPanel(null); head.setBackground(new Color(255,193,7)); head.setBounds(0,0,744,95); p.add(head);
        JLabel title=new JLabel("LA GRAN FAMILIA",SwingConstants.CENTER); title.setFont(new Font("Serif",Font.BOLD,29)); title.setBounds(70,12,604,38); head.add(title);
        JLabel sub=new JLabel("MENÚ DE EMPLEADO",SwingConstants.CENTER); sub.setFont(new Font("Serif",Font.BOLD,17)); sub.setBounds(70,52,604,28); head.add(sub);
        JLabel welcome=new JLabel("Bienvenido: "+nombre,SwingConstants.CENTER); welcome.setFont(new Font("Serif",Font.BOLD,18)); welcome.setBounds(20,105,704,35); p.add(welcome);
        JButton ventas=boton("Registrar venta"); ventas.setBounds(35,165,330,120); p.add(ventas);
        JButton productos=boton("Consultar inventario"); productos.setBounds(395,165,330,120); p.add(productos);
        JButton historial=boton("Ventas recientes"); historial.setBounds(35,315,330,90); p.add(historial);
        JButton salir=new JButton("Cerrar sesión"); salir.setFont(new Font("SansSerif",Font.BOLD,17)); salir.setBackground(new Color(190,45,45)); salir.setForeground(Color.WHITE); salir.setFocusPainted(false); salir.setBorder(BorderFactory.createEmptyBorder(8,16,8,16)); salir.setBounds(395,315,330,90); p.add(salir);
        ventas.addActionListener(e->abrir(new Ventas(idUsuario)));
        productos.addActionListener(e->abrir(new InterfazProducto(true)));
        historial.addActionListener(e->abrir(new HistorialVentas()));
        salir.addActionListener(e -> { if (confirmarCerrarSesion()) { new Login().setVisible(true); dispose(); } });
    }

    private boolean confirmarCerrarSesion() {
        JDialog dialogo = new JDialog(this, "Cerrar sesión", true);
        dialogo.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        dialogo.setSize(390, 205);
        dialogo.setResizable(false);
        dialogo.setLocationRelativeTo(this);
        JPanel principal = new JPanel(new BorderLayout());
        principal.setBackground(new Color(255, 248, 225));
        JPanel encabezado = new JPanel(new BorderLayout());
        encabezado.setBackground(new Color(255, 193, 7));
        encabezado.setBorder(BorderFactory.createEmptyBorder(12, 18, 12, 18));
        JLabel titulo = new JLabel("Cerrar sesión");
        titulo.setFont(new Font("SansSerif", Font.BOLD, 18));
        titulo.setForeground(new Color(45, 45, 45));
        encabezado.add(titulo, BorderLayout.CENTER);
        principal.add(encabezado, BorderLayout.NORTH);
        JLabel mensaje = new JLabel("¿Deseas cerrar tu sesión actual?", SwingConstants.CENTER);
        mensaje.setFont(new Font("SansSerif", Font.PLAIN, 14));
        mensaje.setForeground(new Color(45, 45, 45));
        mensaje.setBorder(BorderFactory.createEmptyBorder(14, 8, 8, 8));
        principal.add(mensaje, BorderLayout.CENTER);
        JPanel botones = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 10));
        botones.setBackground(new Color(255, 248, 225));
        final boolean[] confirmado = {false};
        JButton si = new JButton("Sí, cerrar sesión");
        si.setFont(new Font("SansSerif", Font.BOLD, 12));
        si.setBackground(new Color(190, 45, 45));
        si.setForeground(Color.WHITE);
        si.setFocusPainted(false);
        JButton no = new JButton("Cancelar");
        no.setFont(new Font("SansSerif", Font.BOLD, 12));
        no.setBackground(new Color(211, 232, 157));
        no.setForeground(new Color(45, 45, 45));
        no.setFocusPainted(false);
        si.addActionListener(e -> { confirmado[0] = true; dialogo.dispose(); });
        no.addActionListener(e -> dialogo.dispose());
        botones.add(si); botones.add(no);
        principal.add(botones, BorderLayout.SOUTH);
        dialogo.setContentPane(principal);
        dialogo.getRootPane().setDefaultButton(no);
        dialogo.setVisible(true);
        return confirmado[0];
    }

    private JButton boton(String t){JButton b=new JButton(t);b.setFont(new Font("Serif",Font.BOLD,22));b.setBackground(new Color(211,232,157));return b;}
    private void abrir(JFrame ventana){setVisible(false);ventana.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);ventana.addWindowListener(new WindowAdapter(){@Override public void windowClosed(WindowEvent e){setVisible(true);}});ventana.setVisible(true);}
}
