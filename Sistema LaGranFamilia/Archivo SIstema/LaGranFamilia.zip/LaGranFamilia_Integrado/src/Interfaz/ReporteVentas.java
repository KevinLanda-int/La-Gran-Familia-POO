package Interfaz;

import BD.Conexion;
import Modelo.Venta;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ReporteVentas extends JFrame {
    private final JSpinner fechaInicio = selectorFecha();
    private final JSpinner fechaFin = selectorFecha();
    private final DefaultTableModel modelo = new DefaultTableModel(
            new Object[]{"Folio", "Fecha", "Empleado", "Total"}, 0) {
        @Override public boolean isCellEditable(int fila, int columna) { return false; }
    };
    private final JTable tabla = new JTable(modelo);
    private final JLabel lblResumen = new JLabel("Ventas: 0     Total vendido: $0.00");
    private final List<Venta> ventasActuales = new ArrayList<>();
    private double totalActual = 0.0;
    private final DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    public ReporteVentas() {
        IconoSistema.aplicar(this);
        Color amarillo = new Color(255, 193, 7);
        Color crema = new Color(255, 248, 225);
        Color verde = new Color(211, 232, 157);
        Color texto = new Color(45, 45, 45);

        setTitle("La Gran Familia - Reporte de ventas");
        setSize(900, 560);
        setMinimumSize(new Dimension(760, 460));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(true);
        setLayout(new BorderLayout(0, 0));
        getContentPane().setBackground(crema);

        JPanel encabezado = new JPanel(new BorderLayout());
        encabezado.setBackground(amarillo);
        encabezado.setBorder(BorderFactory.createEmptyBorder(14, 22, 14, 22));
        JLabel titulo = new JLabel("Reporte de ventas");
        titulo.setForeground(texto);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 22));
        JLabel subtitulo = new JLabel("Consulta y exportación de operaciones");
        subtitulo.setForeground(new Color(80, 70, 45));
        subtitulo.setFont(new Font("SansSerif", Font.PLAIN, 12));
        JPanel textosTitulo = new JPanel();
        textosTitulo.setOpaque(false);
        textosTitulo.setLayout(new BoxLayout(textosTitulo, BoxLayout.Y_AXIS));
        textosTitulo.add(titulo);
        textosTitulo.add(Box.createVerticalStrut(3));
        textosTitulo.add(subtitulo);
        encabezado.add(textosTitulo, BorderLayout.WEST);
        add(encabezado, BorderLayout.NORTH);

        JPanel principal = new JPanel(new BorderLayout(0, 12));
        principal.setBackground(crema);
        principal.setBorder(BorderFactory.createEmptyBorder(16, 18, 12, 18));

        JPanel filtros = new JPanel(new FlowLayout(FlowLayout.LEFT, 9, 10));
        filtros.setBackground(Color.WHITE);
        filtros.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(230, 220, 190)),
                BorderFactory.createEmptyBorder(2, 10, 2, 10)));
        JLabel lblDesde = new JLabel("Desde");
        JLabel lblHasta = new JLabel("Hasta");
        lblDesde.setForeground(texto);
        lblHasta.setForeground(texto);
        filtros.add(lblDesde);
        filtros.add(fechaInicio);
        filtros.add(lblHasta);
        filtros.add(fechaFin);
        JButton consultar = new JButton("Consultar");
        consultar.setBackground(verde);
        consultar.setForeground(texto);
        consultar.setFont(new Font("SansSerif", Font.BOLD, 12));
        consultar.setFocusPainted(false);
        consultar.setBorder(BorderFactory.createEmptyBorder(7, 18, 7, 18));
        filtros.add(consultar);

        tabla.setRowHeight(27);
        tabla.setFont(new Font("SansSerif", Font.PLAIN, 12));
        tabla.setForeground(texto);
        tabla.setBackground(Color.WHITE);
        tabla.setGridColor(new Color(232, 226, 210));
        tabla.setShowVerticalLines(false);
        tabla.setSelectionBackground(new Color(255, 239, 184));
        tabla.setSelectionForeground(texto);
        tabla.setFillsViewportHeight(true);
        tabla.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 12));
        tabla.getTableHeader().setBackground(new Color(255, 242, 199));
        tabla.getTableHeader().setForeground(texto);
        tabla.getTableHeader().setPreferredSize(new Dimension(0, 32));
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(230, 220, 190)));
        scroll.getViewport().setBackground(Color.WHITE);

        lblResumen.setOpaque(true);
        lblResumen.setBackground(amarillo);
        lblResumen.setForeground(texto);
        lblResumen.setFont(new Font("SansSerif", Font.BOLD, 13));
        lblResumen.setBorder(BorderFactory.createEmptyBorder(11, 14, 11, 14));

        JPanel tablaPanel = new JPanel(new BorderLayout(0, 0));
        tablaPanel.setBackground(crema);
        tablaPanel.add(scroll, BorderLayout.CENTER);
        tablaPanel.add(lblResumen, BorderLayout.SOUTH);

        principal.add(filtros, BorderLayout.NORTH);
        principal.add(tablaPanel, BorderLayout.CENTER);
        add(principal, BorderLayout.CENTER);

        JPanel abajo = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 12));
        abajo.setBackground(crema);
        abajo.setBorder(BorderFactory.createEmptyBorder(0, 18, 4, 18));
        JButton regresar = new JButton("Regresar al menú");
        regresar.setBackground(Color.WHITE);
        regresar.setForeground(texto);
        regresar.setFocusPainted(false);
        regresar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(210, 200, 170)),
                BorderFactory.createEmptyBorder(8, 16, 8, 16)));
        JButton pdf = new JButton("Generar PDF");
        pdf.setBackground(amarillo);
        pdf.setForeground(texto);
        pdf.setFont(new Font("SansSerif", Font.BOLD, 13));
        pdf.setFocusPainted(false);
        pdf.setBorder(BorderFactory.createEmptyBorder(9, 20, 9, 20));
        regresar.addActionListener(e -> dispose());
        abajo.add(regresar);
        abajo.add(pdf);
        add(abajo, BorderLayout.SOUTH);

        consultar.addActionListener(e -> consultarVentas());
        pdf.addActionListener(e -> generarPDF());
        consultarVentas();
    }

    private static JSpinner selectorFecha() {
        SpinnerDateModel model = new SpinnerDateModel(new Date(), null, null, java.util.Calendar.DAY_OF_MONTH);
        JSpinner spinner = new JSpinner(model);
        spinner.setEditor(new JSpinner.DateEditor(spinner, "dd/MM/yyyy"));
        spinner.setPreferredSize(new Dimension(115, 28));
        return spinner;
    }

    private void consultarVentas() {
        Date inicio = (Date) fechaInicio.getValue();
        Date fin = (Date) fechaFin.getValue();
        if (inicio.after(fin)) {
            JOptionPane.showMessageDialog(this, "La fecha inicial no puede ser posterior a la fecha final.",
                    "Rango inválido", JOptionPane.WARNING_MESSAGE);
            return;
        }
        java.sql.Date sqlInicio = new java.sql.Date(inicio.getTime());
        java.sql.Date sqlFin = new java.sql.Date(fin.getTime());
        String sql = "SELECT v.id_venta, v.fecha, v.total, v.id_usuario, u.nombre " +
                "FROM venta v JOIN usuario u ON u.id_usuario=v.id_usuario " +
                "WHERE v.fecha >= ? AND v.fecha < DATE_ADD(?, INTERVAL 1 DAY) " +
                "ORDER BY v.fecha DESC, v.id_venta DESC";
        try (Connection con = Conexion.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setDate(1, sqlInicio);
            ps.setDate(2, sqlFin);
            try (ResultSet rs = ps.executeQuery()) {
                ventasActuales.clear();
                modelo.setRowCount(0);
                totalActual = 0.0;
                while (rs.next()) {
                    java.sql.Timestamp ts = rs.getTimestamp("fecha");
                    LocalDateTime fecha = ts.toLocalDateTime();
                    Venta venta = new Venta(rs.getInt("id_venta"), fecha, rs.getDouble("total"),
                            rs.getInt("id_usuario"), rs.getString("nombre"));
                    ventasActuales.add(venta);
                    totalActual += venta.getTotal();
                    modelo.addRow(new Object[]{venta.getIdVenta(), fecha.format(formatoFecha),
                            venta.getNombreUsuario(), String.format(Locale.US, "$%.2f", venta.getTotal())});
                }
            }
            lblResumen.setText("Ventas: " + ventasActuales.size() + "     Total vendido: " +
                    String.format(Locale.US, "$%.2f", totalActual));
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "No se pudo consultar el reporte: " + ex.getMessage(),
                    "Error de base de datos", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void generarPDF() {
        if (ventasActuales.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No hay ventas para generar el PDF. Primero consulta un rango con resultados.",
                    "Sin datos", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        FileDialog dialogo = new FileDialog(this, "Guardar reporte de ventas en PDF", FileDialog.SAVE);
        java.io.File documentos = new java.io.File(System.getProperty("user.home"), "Documents");
        if (!documentos.isDirectory()) {
            documentos = new java.io.File(System.getProperty("user.home"), "OneDrive\\Documents");
        }
        if (documentos.isDirectory()) {
            dialogo.setDirectory(documentos.getAbsolutePath());
        }
        dialogo.setFile("Reporte_Ventas.pdf");
        dialogo.setVisible(true);
        if (dialogo.getFile() == null || dialogo.getDirectory() == null) return;
        Path destino = java.nio.file.Paths.get(dialogo.getDirectory(), dialogo.getFile());
        if (!destino.toString().toLowerCase(Locale.ROOT).endsWith(".pdf")) {
            destino = java.nio.file.Paths.get(destino.toString() + ".pdf");
        }
        try {
            escribirPDF(destino, "");
            JOptionPane.showMessageDialog(this, "PDF generado correctamente:\n" + destino.toAbsolutePath(),
                    "Reporte generado", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "No se pudo generar el PDF: " + ex.getMessage(),
                    "Error al generar PDF", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String crearContenidoPDF() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        StringBuilder s = new StringBuilder();
        s.append("LA GRAN FAMILIA").append('\n');
        s.append("REPORTE DE VENTAS").append('\n');
        s.append("Periodo: ").append(sdf.format((Date) fechaInicio.getValue())).append(" - ")
                .append(sdf.format((Date) fechaFin.getValue())).append('\n');
        s.append("Ventas registradas: ").append(ventasActuales.size()).append('\n');
        s.append("Total vendido: ").append(String.format(Locale.US, "$%.2f", totalActual)).append('\n');
        s.append("--------------------------------------------------------------------------").append('\n');
        s.append(String.format("%-8s %-18s %-27s %12s", "FOLIO", "FECHA", "EMPLEADO", "TOTAL")).append('\n');
        s.append("--------------------------------------------------------------------------").append('\n');
        for (Venta v : ventasActuales) {
            String empleado = v.getNombreUsuario() == null ? "" : v.getNombreUsuario();
            if (empleado.length() > 25) empleado = empleado.substring(0, 25);
            s.append(String.format(Locale.US, "%-8d %-18s %-27s %12s", v.getIdVenta(),
                    v.getFecha().format(formatoFecha), empleado,
                    String.format(Locale.US, "$%.2f", v.getTotal()))).append('\n');
            s.append("  ARTICULOS DE LA VENTA #").append(v.getIdVenta()).append('\n');
            s.append(String.format("  %-28s %7s %12s %12s", "ARTICULO", "CANT.", "PRECIO", "SUBTOTAL")).append('\n');
            String sqlDetalle = "SELECT p.nombre, dv.cantidad, dv.precio_unitario, dv.subtotal " +
                    "FROM detalle_venta dv JOIN producto p ON p.id_producto=dv.id_producto " +
                    "WHERE dv.id_venta=? ORDER BY p.nombre";
            try (Connection con = Conexion.conectar(); PreparedStatement ps = con.prepareStatement(sqlDetalle)) {
                ps.setInt(1, v.getIdVenta());
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        String articulo = rs.getString("nombre");
                        if (articulo == null) articulo = "";
                        if (articulo.length() > 28) articulo = articulo.substring(0, 28);
                        s.append(String.format(Locale.US, "  %-28s %7d %12s %12s", articulo,
                                rs.getInt("cantidad"), String.format(Locale.US, "$%.2f", rs.getDouble("precio_unitario")),
                                String.format(Locale.US, "$%.2f", rs.getDouble("subtotal")))).append('\n');
                    }
                }
            } catch (SQLException ex) {
                s.append("  No fue posible leer los articulos: ").append(ex.getMessage()).append('\n');
            }
            s.append('\n');
        }
        return s.toString();
    }


    private void escribirPDF(Path destino, String texto) throws IOException {
        List<String> streams = new ArrayList<>();
        StringBuilder stream = new StringBuilder();
        float[] y = new float[]{0};
        iniciarPagina(stream, y);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        String periodo = "Periodo: " + sdf.format((Date) fechaInicio.getValue()) + " - " +
                sdf.format((Date) fechaFin.getValue());

        for (Venta venta : ventasActuales) {
            List<String[]> articulos = new ArrayList<>();
            String sqlDetalle = "SELECT p.nombre, dv.cantidad, dv.precio_unitario, dv.subtotal " +
                    "FROM detalle_venta dv JOIN producto p ON p.id_producto=dv.id_producto " +
                    "WHERE dv.id_venta=? ORDER BY p.nombre";
            try (Connection con = Conexion.conectar();
                 PreparedStatement ps = con.prepareStatement(sqlDetalle)) {
                ps.setInt(1, venta.getIdVenta());
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        articulos.add(new String[]{
                                rs.getString("nombre") == null ? "" : rs.getString("nombre"),
                                String.valueOf(rs.getInt("cantidad")),
                                String.format(Locale.US, "$%.2f", rs.getDouble("precio_unitario")),
                                String.format(Locale.US, "$%.2f", rs.getDouble("subtotal"))
                        });
                    }
                }
            } catch (SQLException ex) {
                articulos.add(new String[]{"No fue posible leer los artículos", "", "", ""});
            }

            if (y[0] < 120) {
                finalizarPagina(stream, streams, streams.size() + 1);
                stream = new StringBuilder();
                iniciarPagina(stream, y);
            }

            rect(stream, 36, y[0] - 6, 540, 25, 0.82, 0.91, 0.62);
            textoPDF(stream, true, 10, 47, y[0] + 2, "ARTÍCULOS DE LA VENTA #" + venta.getIdVenta());
            y[0] -= 32;

            rect(stream, 36, y[0] - 5, 540, 20, 1, 0.757, 0.027);
            textoPDF(stream, true, 8, 44, y[0] + 1, "FOLIO");
            textoPDF(stream, true, 8, 100, y[0] + 1, "FECHA");
            textoPDF(stream, true, 8, 245, y[0] + 1, "EMPLEADO");
            textoPDF(stream, true, 8, 490, y[0] + 1, "TOTAL");
            y[0] -= 22;

            String fecha = venta.getFecha() == null ? "" : venta.getFecha().format(formatoFecha);
            String empleado = venta.getNombreUsuario() == null ? "" : venta.getNombreUsuario();
            if (empleado.length() > 28) empleado = empleado.substring(0, 28);
            textoPDF(stream, false, 8, 44, y[0], String.valueOf(venta.getIdVenta()));
            textoPDF(stream, false, 8, 100, y[0], fecha);
            textoPDF(stream, false, 8, 245, y[0], empleado);
            textoPDF(stream, true, 8, 490, y[0], String.format(Locale.US, "$%.2f", venta.getTotal()));
            y[0] -= 24;

            rect(stream, 42, y[0] - 5, 528, 18, 1, 0.757, 0.027);
            textoPDF(stream, true, 8, 49, y[0] + 1, "ARTÍCULO");
            textoPDF(stream, true, 8, 335, y[0] + 1, "CANT.");
            textoPDF(stream, true, 8, 390, y[0] + 1, "PRECIO");
            textoPDF(stream, true, 8, 475, y[0] + 1, "SUBTOTAL");
            y[0] -= 22;

            if (articulos.isEmpty()) {
                textoPDF(stream, false, 8, 49, y[0], "Esta venta no tiene artículos registrados.");
                y[0] -= 16;
            } else {
                for (String[] articulo : articulos) {
                    if (y[0] < 65) {
                        finalizarPagina(stream, streams, streams.size() + 1);
                        stream = new StringBuilder();
                        iniciarPagina(stream, y);
                        rect(stream, 42, y[0] - 5, 528, 18, 1, 0.757, 0.027);
                        textoPDF(stream, true, 8, 49, y[0] + 1, "ARTÍCULO");
                        textoPDF(stream, true, 8, 335, y[0] + 1, "CANT.");
                        textoPDF(stream, true, 8, 390, y[0] + 1, "PRECIO");
                        textoPDF(stream, true, 8, 475, y[0] + 1, "SUBTOTAL");
                        y[0] -= 22;
                    }
                    String nombre = articulo[0];
                    if (nombre.length() > 47) nombre = nombre.substring(0, 44) + "...";
                    textoPDF(stream, false, 8, 49, y[0], nombre);
                    textoPDF(stream, false, 8, 345, y[0], articulo[1]);
                    textoPDF(stream, false, 8, 390, y[0], articulo[2]);
                    textoPDF(stream, false, 8, 485, y[0], articulo[3]);
                    stream.append("q 0.88 0.88 0.88 RG 45 ").append(y[0] - 4)
                            .append(" m 567 ").append(y[0] - 4).append(" l S Q\n");
                    y[0] -= 16;
                }
            }
            y[0] -= 12;
        }

        finalizarPagina(stream, streams, streams.size() + 1);
        escribirDocumentoPDF(destino, streams);
    }

    private void iniciarPagina(StringBuilder stream, float[] y) {
        stream.append("q 0.99 0.98 0.94 rg 0 0 612 792 re f Q\n");
        rect(stream, 0, 692, 612, 100, 1, 0.757, 0.027);
        textoPDF(stream, true, 22, 38, 752, "LA GRAN FAMILIA");
        textoPDF(stream, true, 12, 39, 729, "REPORTE DE VENTAS");
        textoPDF(stream, false, 9, 39, 710, "Consulta de operaciones y artículos vendidos");

        rect(stream, 36, 642, 540, 37, 1, 1, 1);
        rect(stream, 36, 642, 4, 37, 0.86, 0.93, 0.72);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        textoPDF(stream, false, 9, 49, 661, "Periodo: " +
                sdf.format((Date) fechaInicio.getValue()) + " - " +
                sdf.format((Date) fechaFin.getValue()));
        textoPDF(stream, false, 9, 49, 647, "Ventas registradas: " + ventasActuales.size());
        rect(stream, 390, 642, 186, 37, 0.86, 0.93, 0.72);
        textoPDF(stream, true, 9, 402, 661, "TOTAL VENDIDO");
        textoPDF(stream, true, 15, 402, 645, String.format(Locale.US, "$%.2f", totalActual));
        y[0] = 620;
    }

    private void finalizarPagina(StringBuilder stream, List<String> streams, int numeroPagina) {
        stream.append("q 0.75 0.75 0.75 RG 36 43 m 576 43 l S Q\n");
        textoPDF(stream, false, 8, 38, 28, "La Gran Familia | Reporte de ventas");
        textoPDF(stream, true, 8, 500, 28, "Página " + numeroPagina);
        streams.add(stream.toString());
    }

    private void rect(StringBuilder stream, float x, float y, float ancho, float alto,
                      double r, double g, double b) {
        stream.append("q ").append(r).append(" ").append(g).append(" ").append(b)
                .append(" rg ").append(x).append(" ").append(y).append(" ")
                .append(ancho).append(" ").append(alto).append(" re f Q\n");
    }

    private void textoPDF(StringBuilder stream, boolean negrita, int tamano,
                          float x, float y, String texto) {
        stream.append("BT /").append(negrita ? "F2" : "F1").append(" ")
                .append(tamano).append(" Tf ").append(x).append(" ").append(y)
                .append(" Td (").append(escaparPDF(texto)).append(") Tj ET\n");
    }

    private void escribirDocumentoPDF(Path destino, List<String> paginas) throws IOException {
        List<byte[]> objetos = new ArrayList<>();
        objetos.add(null);
        objetos.add(null);
        objetos.add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>"
                .getBytes(StandardCharsets.US_ASCII));
        objetos.add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>"
                .getBytes(StandardCharsets.US_ASCII));
        List<Integer> idsPagina = new ArrayList<>();

        for (String pagina : paginas) {
            int idPagina = objetos.size() + 1;
            int idContenido = idPagina + 1;
            idsPagina.add(idPagina);
            objetos.add(("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] " +
                    "/Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents " +
                    idContenido + " 0 R >>").getBytes(StandardCharsets.US_ASCII));

            byte[] contenido = pagina.getBytes(StandardCharsets.ISO_8859_1);
            java.io.ByteArrayOutputStream objContenido = new java.io.ByteArrayOutputStream();
            objContenido.write(("<< /Length " + contenido.length + " >>\nstream\n")
                    .getBytes(StandardCharsets.US_ASCII));
            objContenido.write(contenido);
            objContenido.write("\nendstream".getBytes(StandardCharsets.US_ASCII));
            objetos.add(objContenido.toByteArray());
        }

        StringBuilder kids = new StringBuilder();
        for (Integer id : idsPagina) kids.append(id).append(" 0 R ");
        objetos.set(0, "<< /Type /Catalog /Pages 2 0 R >>".getBytes(StandardCharsets.US_ASCII));
        objetos.set(1, ("<< /Type /Pages /Kids [" + kids + "] /Count " + paginas.size() + " >>")
                .getBytes(StandardCharsets.US_ASCII));

        java.io.ByteArrayOutputStream pdf = new java.io.ByteArrayOutputStream();
        pdf.write("%PDF-1.4\n".getBytes(StandardCharsets.US_ASCII));
        List<Integer> offsets = new ArrayList<>();
        offsets.add(0);
        for (int i = 0; i < objetos.size(); i++) {
            offsets.add(pdf.size());
            pdf.write(((i + 1) + " 0 obj\n").getBytes(StandardCharsets.US_ASCII));
            pdf.write(objetos.get(i));
            pdf.write("\nendobj\n".getBytes(StandardCharsets.US_ASCII));
        }
        int xref = pdf.size();
        pdf.write(("xref\n0 " + (objetos.size() + 1) +
                "\n0000000000 65535 f \n").getBytes(StandardCharsets.US_ASCII));
        for (int i = 1; i < offsets.size(); i++) {
            pdf.write(String.format(Locale.US, "%010d 00000 n \n", offsets.get(i))
                    .getBytes(StandardCharsets.US_ASCII));
        }
        pdf.write(("trailer\n<< /Size " + (objetos.size() + 1) +
                " /Root 1 0 R >>\nstartxref\n" + xref + "\n%%EOF")
                .getBytes(StandardCharsets.US_ASCII));
        Files.write(destino, pdf.toByteArray());
    }

    private static String escaparPDF(String texto) {
        return texto.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
                .replaceAll("[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F]", " ");
    }
}
