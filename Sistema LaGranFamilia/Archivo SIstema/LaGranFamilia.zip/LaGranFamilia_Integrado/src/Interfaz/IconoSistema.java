package Interfaz;

import javax.swing.ImageIcon;
import java.awt.Image;
import java.net.URL;

public final class IconoSistema {
    private IconoSistema() { }

    public static void aplicar(javax.swing.JFrame ventana) {
        URL recurso = IconoSistema.class.getResource("/recursos/logo_la_gran_familia.png");
        if (recurso != null) {
            Image imagen = new ImageIcon(recurso).getImage();
            ventana.setIconImage(imagen.getScaledInstance(64, 64, Image.SCALE_SMOOTH));
        }
    }
}
