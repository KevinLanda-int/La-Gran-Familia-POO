package Interfaz;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;
import Modelo.Producto;
import Servicios.InventarioServicio;

public class InterfazProducto extends JFrame {
    private final InventarioServicio inventario = new InventarioServicio();
    private final JTextField txtNombre = new JTextField(18);
    private final JTextField txtPrecio = new JTextField(18);
    private final JTextField txtStock = new JTextField(18);
    private final DefaultTableModel modelo = new DefaultTableModel(
        new Object[]{"ID", "Nombre", "Precio", "Stock"}, 0) {
        @Override
        public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable tabla = new JTable(modelo);
    private final boolean soloConsulta;
    private final Color AMARILLO = new Color(255, 193, 7);
    private final Color CREMA = new Color(255, 248, 225);
    private final Color VERDE = new Color(211, 232, 157);
    private final Color VERDE_HOVER = new Color(190, 218, 125);
    private final Color OSCURO = new Color(45, 45, 45);

    public InterfazProducto() { this(false); }

    public InterfazProducto(boolean soloConsulta) {
        IconoSistema.aplicar(this);
        this.soloConsulta = soloConsulta;
        setTitle("La Gran Familia - Productos");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setMinimumSize(new Dimension(760, 520));
        setSize(900, 650);
        setLocationRelativeTo(null);
        setResizable(true);

        JPanel principal = new JPanel(new BorderLayout(14, 14));
        principal.setBackground(AMARILLO);
        principal.setBorder(BorderFactory.createEmptyBorder(18, 22, 16, 22));
        setContentPane(principal);

        JLabel titulo = new JLabel("LA GRAN FAMILIA - INVENTARIO", SwingConstants.CENTER);
        titulo.setFont(new Font("Serif", Font.BOLD, 28));
        titulo.setForeground(OSCURO);
        titulo.setBorder(BorderFactory.createEmptyBorder(0, 0, 8, 0));
        principal.add(titulo, BorderLayout.NORTH);

        JPanel zonaSuperior = new JPanel(new BorderLayout(22, 8));
        zonaSuperior.setOpaque(false);
        JPanel formulario = new JPanel(new GridBagLayout());
        formulario.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 4, 5, 12);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        agregarCampo(formulario, gbc, 0, "Nombre:", txtNombre);
        agregarCampo(formulario, gbc, 1, "Precio:", txtPrecio);
        agregarCampo(formulario, gbc, 2, "Stock:", txtStock);
        zonaSuperior.add(formulario, BorderLayout.WEST);

        JPanel acciones = new JPanel(new GridLayout(0, 2, 10, 9));
        acciones.setOpaque(false);
        JButton registrar = boton("Registrar", true);
        JButton modificar = boton("Modificar", true);
        JButton eliminar = boton("Eliminar", true);
        JButton actualizar = boton("Actualizar", true);
        JButton limpiar = boton("Limpiar", true);
        acciones.add(registrar);
        acciones.add(modificar);
        acciones.add(eliminar);
        acciones.add(actualizar);
        acciones.add(limpiar);
        zonaSuperior.add(acciones, BorderLayout.CENTER);

        if (soloConsulta) {
            txtNombre.setEditable(false);
            txtPrecio.setEditable(false);
            txtStock.setEditable(false);
            registrar.setVisible(false);
            modificar.setVisible(false);
            eliminar.setVisible(false);
            limpiar.setVisible(false);
        }

        JPanel centro = new JPanel(new BorderLayout(0, 8));
        centro.setOpaque(false);
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabla.setRowHeight(27);
        tabla.setFont(new Font("SansSerif", Font.PLAIN, 14));
        tabla.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 14));
        tabla.getTableHeader().setBackground(CREMA);
        tabla.setSelectionBackground(VERDE);
        tabla.setSelectionForeground(OSCURO);
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(210, 190, 120)));
        centro.add(scroll, BorderLayout.CENTER);

        JPanel inferior = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        inferior.setOpaque(false);
        JButton regresar = boton("Regresar al menú principal", false);
        regresar.setPreferredSize(new Dimension(260, 40));
        inferior.add(regresar);

        JPanel cuerpo = new JPanel(new BorderLayout(0, 14));
        cuerpo.setOpaque(false);
        cuerpo.add(zonaSuperior, BorderLayout.NORTH);
        cuerpo.add(centro, BorderLayout.CENTER);
        cuerpo.add(inferior, BorderLayout.SOUTH);
        principal.add(cuerpo, BorderLayout.CENTER);

        regresar.addActionListener(e -> dispose());
        tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tabla.getSelectedRow() >= 0) {
                int r = tabla.getSelectedRow();
                txtNombre.setText(modelo.getValueAt(r, 1).toString());
                txtPrecio.setText(modelo.getValueAt(r, 2).toString());
                txtStock.setText(modelo.getValueAt(r, 3).toString());
            }
        });
        registrar.addActionListener(e -> ejecutar(0));
        modificar.addActionListener(e -> ejecutar(1));
        eliminar.addActionListener(e -> borrar());
        actualizar.addActionListener(e -> cargarTabla());
        limpiar.addActionListener(e -> limpiar());
        cargarTabla();
    }

    private void agregarCampo(JPanel panel, GridBagConstraints gbc, int fila,
                              String texto, JTextField campo) {
        gbc.gridx = 0;
        gbc.gridy = fila;
        gbc.weightx = 0;
        JLabel etiqueta = new JLabel(texto);
        etiqueta.setFont(new Font("SansSerif", Font.BOLD, 14));
        etiqueta.setForeground(OSCURO);
        panel.add(etiqueta, gbc);
        gbc.gridx = 1;
        gbc.weightx = 1;
        campo.setPreferredSize(new Dimension(240, 32));
        panel.add(campo, gbc);
    }

    private JButton boton(String texto, boolean accion) {
        JButton b = new JButton(texto);
        b.setFont(new Font("SansSerif", Font.BOLD, 14));
        b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setBackground(accion ? new Color(204, 204, 0) : VERDE);
        b.setForeground(OSCURO);
        b.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(180, 170, 50)),
            BorderFactory.createEmptyBorder(7, 12, 7, 12)));
        b.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseEntered(java.awt.event.MouseEvent e) {
                b.setBackground(VERDE_HOVER);
            }
            @Override public void mouseExited(java.awt.event.MouseEvent e) {
                b.setBackground(accion ? new Color(204, 204, 0) : VERDE);
            }
        });
        return b;
    }

    private void ejecutar(int tipo) {
        try {
            String nombre = txtNombre.getText().trim();
            double precio = Double.parseDouble(txtPrecio.getText().trim().replace(',', '.'));
            int stock = Integer.parseInt(txtStock.getText().trim());
            boolean ok;
            if (tipo == 0) {
                ok = inventario.registrarProducto(nombre, precio, stock);
            } else {
                int r = tabla.getSelectedRow();
                if (r < 0) {
                    mensaje("Selecciona un producto de la tabla.");
                    return;
                }
                int id = Integer.parseInt(modelo.getValueAt(r, 0).toString());
                ok = inventario.modificarProducto(id, nombre, precio, stock);
            }
            if (ok) {
                mensaje(tipo == 0 ? "Producto registrado correctamente." : "Producto modificado correctamente.");
                limpiar();
                cargarTabla();
            } else {
                mensaje("No se realizó la operación.");
            }
        } catch (NumberFormatException ex) {
            mensaje("Escribe un precio válido y un stock entero.");
        } catch (IllegalArgumentException ex) {
            mensaje(ex.getMessage());
        } catch (SQLException ex) {
            mensaje("Error de base de datos: " + ex.getMessage());
        }
    }

    private void borrar() {
        int r = tabla.getSelectedRow();
        if (r < 0) {
            mensaje("Selecciona un producto.");
            return;
        }
        int id = Integer.parseInt(modelo.getValueAt(r, 0).toString());
        if (JOptionPane.showConfirmDialog(this, "¿Eliminar el producto seleccionado?",
                "Confirmar", JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;
        try {
            if (inventario.eliminarProducto(id)) {
                mensaje("Producto eliminado.");
                limpiar();
                cargarTabla();
            } else {
                mensaje("No se pudo eliminar el producto. Puede tener ventas asociadas.");
            }
        } catch (SQLException ex) {
            mensaje("No se pudo eliminar: " + ex.getMessage());
        }
    }

    private void cargarTabla() {
        try {
            List<Producto> productos = inventario.consultarProductos();
            modelo.setRowCount(0);
            for (Producto x : productos) {
                modelo.addRow(new Object[]{x.getId_producto(), x.getNombre(), x.getPrecio(), x.getStock()});
            }
        } catch (SQLException ex) {
            mensaje("No se pudo consultar el inventario: " + ex.getMessage());
        }
    }

    private void limpiar() {
        txtNombre.setText("");
        txtPrecio.setText("");
        txtStock.setText("");
        tabla.clearSelection();
    }

    private void mensaje(String m) {
        JOptionPane.showMessageDialog(this, m);
    }
}
