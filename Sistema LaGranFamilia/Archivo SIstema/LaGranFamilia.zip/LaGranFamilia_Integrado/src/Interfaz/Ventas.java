package Interfaz;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import BD.ProductoBD;
import Modelo.Producto;
import Modelo.ResultadoVenta;
import Servicios.GestorVentas;

public class Ventas extends JFrame {
    private final int idUsuario;
    private final JComboBox<Producto> cmbProducto = new JComboBox<>();
    private final JTextField txtCantidad = new JTextField("1");
    private final JTextField txtPrecio = new JTextField();
    private final JTextField txtTotal = new JTextField("$0.00");
    private final DefaultTableModel modeloCarrito = new DefaultTableModel(
            new Object[]{"ID", "Producto", "Cantidad", "Precio", "Subtotal"}, 0) {
        @Override public boolean isCellEditable(int fila, int columna) { return false; }
    };
    private final JTable tablaCarrito = new JTable(modeloCarrito);
    private final Map<Integer, Integer> carrito = new LinkedHashMap<>();
    private final GestorVentas gestor = new GestorVentas();
    private final ProductoBD productoBD = new ProductoBD();

    public Ventas() { this(1); }

    public Ventas(int idUsuario) {
        IconoSistema.aplicar(this);
        this.idUsuario = idUsuario;
        setTitle("La Gran Familia - Registrar venta");
        setSize(760, 570);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(true);
        setMinimumSize(new Dimension(700, 520));

        JPanel p = new JPanel(null);
        p.setBackground(new Color(255, 220, 80));
        setContentPane(p);
        ResponsiveAbsoluteLayout.attach(p, new Dimension(760, 570));

        JLabel title = new JLabel("REGISTRAR VENTA", SwingConstants.CENTER);
        title.setFont(new Font("Serif", Font.BOLD, 24));
        title.setBounds(20, 12, 705, 35);
        p.add(title);

        JLabel lp = new JLabel("Producto:"); lp.setBounds(25, 60, 90, 25); p.add(lp);
        cmbProducto.setBounds(115, 60, 365, 28); p.add(cmbProducto);
        JLabel lc = new JLabel("Cantidad:"); lc.setBounds(25, 98, 90, 25); p.add(lc);
        txtCantidad.setBounds(115, 98, 90, 28); p.add(txtCantidad);
        JLabel lpr = new JLabel("Precio:"); lpr.setBounds(225, 98, 55, 25); p.add(lpr);
        txtPrecio.setEditable(false); txtPrecio.setBounds(280, 98, 100, 28); p.add(txtPrecio);
        JLabel lt = new JLabel("Total de la venta:"); lt.setFont(new Font("Arial", Font.BOLD, 15)); lt.setBounds(500, 98, 135, 25); p.add(lt);
        txtTotal.setEditable(false); txtTotal.setFont(new Font("Arial", Font.BOLD, 16)); txtTotal.setBounds(630, 96, 95, 30); p.add(txtTotal);

        JButton btnAgregar = new JButton("Agregar producto"); btnAgregar.setBounds(490, 60, 145, 28); p.add(btnAgregar);
        JButton btnQuitar = new JButton("Quitar seleccionado"); btnQuitar.setBounds(490, 135, 145, 30); p.add(btnQuitar);
        JButton btnLimpiar = new JButton("Vaciar carrito"); btnLimpiar.setBounds(640, 135, 90, 30); p.add(btnLimpiar);

        JLabel lcarr = new JLabel("PRODUCTOS DE ESTA VENTA");
        lcarr.setFont(new Font("Serif", Font.BOLD, 16)); lcarr.setBounds(25, 140, 300, 25); p.add(lcarr);
        tablaCarrito.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tablaCarrito.setRowHeight(23);
        JScrollPane scroll = new JScrollPane(tablaCarrito); scroll.setBounds(25, 175, 705, 275); p.add(scroll);

        JButton btnRegistrar = new JButton("Registrar venta completa");
        btnRegistrar.setFont(new Font("Arial", Font.BOLD, 14));
        btnRegistrar.setBackground(new Color(204, 204, 0));
        btnRegistrar.setBounds(220, 470, 230, 38); p.add(btnRegistrar);
        JButton btnActualizar = new JButton("Actualizar inventario"); btnActualizar.setBounds(475, 470, 200, 38); p.add(btnActualizar);
        JButton btnRegresar = new JButton("Regresar al menú principal");
        btnRegresar.setFont(new Font("Arial", Font.BOLD, 13));
        btnRegresar.setBackground(new Color(211, 232, 157));
        btnRegresar.setBounds(25, 470, 185, 38);
        p.add(btnRegresar);
        btnRegresar.addActionListener(e -> dispose());

        cmbProducto.addActionListener(e -> actualizarPrecio());
        btnAgregar.addActionListener(e -> agregarProducto());
        btnQuitar.addActionListener(e -> quitarProducto());
        btnLimpiar.addActionListener(e -> vaciarCarrito());
        btnRegistrar.addActionListener(e -> registrar());
        btnActualizar.addActionListener(e -> cargarProductos());
        cargarProductos();
    }

    private void cargarProductos() {
        try {
            Producto seleccionado = (Producto) cmbProducto.getSelectedItem();
            int idSeleccionado = seleccionado == null ? -1 : seleccionado.getId_producto();
            cmbProducto.removeAllItems();
            List<Producto> productos = productoBD.consultarProductos();
            for (Producto p : productos) {
                if (p.getStock() > 0) cmbProducto.addItem(p);
            }
            for (int i = 0; i < cmbProducto.getItemCount(); i++) {
                if (cmbProducto.getItemAt(i).getId_producto() == idSeleccionado) {
                    cmbProducto.setSelectedIndex(i);
                    break;
                }
            }
            actualizarPrecio();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "No se pudo cargar el inventario: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void actualizarPrecio() {
        Producto p = (Producto) cmbProducto.getSelectedItem();
        if (p == null) { txtPrecio.setText(""); return; }
        txtPrecio.setText(String.format(java.util.Locale.US, "%.2f", p.getPrecio()));
    }

    private int cantidadSolicitada() {
        int c = Integer.parseInt(txtCantidad.getText().trim());
        if (c <= 0) throw new NumberFormatException();
        return c;
    }

    private void agregarProducto() {
        Producto p = (Producto) cmbProducto.getSelectedItem();
        if (p == null) {
            JOptionPane.showMessageDialog(this, "No hay productos con existencias disponibles.");
            return;
        }
        try {
            int cantidad = cantidadSolicitada();
            int yaAgregado = carrito.getOrDefault(p.getId_producto(), 0);
            int nuevaCantidad = yaAgregado + cantidad;
            if (nuevaCantidad > p.getStock()) {
                JOptionPane.showMessageDialog(this, "Stock insuficiente para " + p.getNombre() + ". Disponible: " + p.getStock() + ". Ya agregado: " + yaAgregado + ".");
                return;
            }
            carrito.put(p.getId_producto(), nuevaCantidad);
            refrescarCarrito();
            txtCantidad.setText("1");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "La cantidad debe ser un entero mayor que cero.");
        }
    }

    private void quitarProducto() {
        int fila = tablaCarrito.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(this, "Selecciona un producto del carrito.");
            return;
        }
        int id = Integer.parseInt(modeloCarrito.getValueAt(fila, 0).toString());
        carrito.remove(id);
        refrescarCarrito();
    }

    private void vaciarCarrito() {
        carrito.clear();
        refrescarCarrito();
    }

    private void refrescarCarrito() {
        modeloCarrito.setRowCount(0);
        double total = 0.0;
        for (Map.Entry<Integer, Integer> item : carrito.entrySet()) {
            Producto producto = buscarProducto(item.getKey());
            if (producto == null) continue;
            int cantidad = item.getValue();
            double subtotal = producto.getPrecio() * cantidad;
            total += subtotal;
            modeloCarrito.addRow(new Object[]{producto.getId_producto(), producto.getNombre(), cantidad,
                    String.format(java.util.Locale.US, "$%.2f", producto.getPrecio()),
                    String.format(java.util.Locale.US, "$%.2f", subtotal)});
        }
        txtTotal.setText(String.format(java.util.Locale.US, "$%.2f", total));
    }

    private Producto buscarProducto(int id) {
        for (int i = 0; i < cmbProducto.getItemCount(); i++) {
            Producto p = cmbProducto.getItemAt(i);
            if (p.getId_producto() == id) return p;
        }

        try {
            for (Producto p : productoBD.consultarProductos()) if (p.getId_producto() == id) return p;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "No se pudo consultar el producto: " + ex.getMessage());
        }
        return null;
    }

    private boolean confirmarVenta() {
        JDialog dialogo = new JDialog(this, "Confirmar venta", true);
        dialogo.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        dialogo.setSize(440, 235);
        dialogo.setResizable(false);
        dialogo.setLocationRelativeTo(this);

        JPanel principal = new JPanel(new BorderLayout(0, 0));
        principal.setBackground(new Color(255, 248, 225));
        JPanel encabezado = new JPanel(new BorderLayout());
        encabezado.setBackground(new Color(255, 193, 7));
        encabezado.setBorder(BorderFactory.createEmptyBorder(13, 18, 13, 18));
        JLabel titulo = new JLabel("Confirmar venta");
        titulo.setFont(new Font("SansSerif", Font.BOLD, 18));
        titulo.setForeground(new Color(40, 40, 40));
        encabezado.add(titulo, BorderLayout.CENTER);
        principal.add(encabezado, BorderLayout.NORTH);

        JPanel centro = new JPanel(new BorderLayout(14, 0));
        centro.setBackground(new Color(255, 248, 225));
        centro.setBorder(BorderFactory.createEmptyBorder(18, 20, 14, 20));
        JLabel icono = new JLabel("?", SwingConstants.CENTER);
        icono.setFont(new Font("SansSerif", Font.BOLD, 24));
        icono.setForeground(new Color(45, 45, 45));
        icono.setOpaque(true);
        icono.setBackground(new Color(255, 193, 7));
        icono.setPreferredSize(new Dimension(42, 42));
        icono.setBorder(BorderFactory.createLineBorder(new Color(220, 165, 0)));
        JLabel mensaje = new JLabel("<html><div style='width:300px'>¿Registrar la venta con <b>" + carrito.size()
                + " producto(s) diferente(s)</b> por <b>" + txtTotal.getText() + "</b>?</div></html>");
        mensaje.setFont(new Font("SansSerif", Font.PLAIN, 14));
        mensaje.setForeground(new Color(45, 45, 45));
        centro.add(icono, BorderLayout.WEST);
        centro.add(mensaje, BorderLayout.CENTER);
        principal.add(centro, BorderLayout.CENTER);

        JPanel botones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 12));
        botones.setBackground(new Color(255, 248, 225));
        botones.setBorder(BorderFactory.createEmptyBorder(0, 10, 4, 14));
        final boolean[] confirmado = {false};
        JButton si = new JButton("Sí, registrar venta");
        si.setFont(new Font("SansSerif", Font.BOLD, 13));
        si.setBackground(new Color(255, 193, 7));
        si.setForeground(new Color(40, 40, 40));
        si.setFocusPainted(false);
        JButton no = new JButton("Cancelar");
        no.setFont(new Font("SansSerif", Font.BOLD, 13));
        no.setBackground(new Color(211, 232, 157));
        no.setForeground(new Color(40, 40, 40));
        no.setFocusPainted(false);
        si.addActionListener(e -> { confirmado[0] = true; dialogo.dispose(); });
        no.addActionListener(e -> dialogo.dispose());
        botones.add(no);
        botones.add(si);
        principal.add(botones, BorderLayout.SOUTH);
        dialogo.setContentPane(principal);
        dialogo.getRootPane().setDefaultButton(si);
        dialogo.setVisible(true);
        return confirmado[0];
    }

    private void mostrarVentaCompletada(ResultadoVenta resultado, int productosDiferentes) {
        JDialog dialogo = new JDialog(this, "Venta completada", true);
        dialogo.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        dialogo.setSize(410, 310);
        dialogo.setResizable(false);
        dialogo.setLocationRelativeTo(this);

        JPanel principal = new JPanel(new BorderLayout());
        principal.setBackground(new Color(255, 248, 225));
        JPanel encabezado = new JPanel(new BorderLayout());
        encabezado.setBackground(new Color(255, 193, 7));
        encabezado.setBorder(BorderFactory.createEmptyBorder(13, 18, 13, 18));
        JLabel titulo = new JLabel("¡Venta completada!");
        titulo.setFont(new Font("SansSerif", Font.BOLD, 18));
        titulo.setForeground(new Color(40, 40, 40));
        encabezado.add(titulo, BorderLayout.CENTER);
        principal.add(encabezado, BorderLayout.NORTH);

        JPanel contenido = new JPanel(new BorderLayout(14, 0));
        contenido.setBackground(new Color(255, 248, 225));
        contenido.setBorder(BorderFactory.createEmptyBorder(18, 22, 14, 22));
        JLabel icono = new JLabel("✓", SwingConstants.CENTER);
        icono.setFont(new Font("SansSerif", Font.BOLD, 27));
        icono.setForeground(Color.WHITE);
        icono.setOpaque(true);
        icono.setBackground(new Color(92, 145, 55));
        icono.setPreferredSize(new Dimension(48, 48));
        JLabel datos = new JLabel("<html><div style='width:270px;line-height:1.5'>"
                + "<b>La venta se registró correctamente.</b><br><br>"
                + "Folio: <b>" + resultado.getIdVenta() + "</b><br>"
                + "Productos diferentes: " + productosDiferentes + "<br>"
                + "Unidades: " + resultado.getCantidad() + "<br>"
                + "Total: <b>$" + String.format(java.util.Locale.US, "%.2f", resultado.getTotal())
                + "</b></div></html>");
        datos.setFont(new Font("SansSerif", Font.PLAIN, 14));
        datos.setForeground(new Color(45, 45, 45));
        contenido.add(icono, BorderLayout.WEST);
        contenido.add(datos, BorderLayout.CENTER);
        principal.add(contenido, BorderLayout.CENTER);

        JPanel pie = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 12));
        pie.setBackground(new Color(255, 248, 225));
        JButton aceptar = new JButton("Aceptar");
        aceptar.setFont(new Font("SansSerif", Font.BOLD, 13));
        aceptar.setBackground(new Color(255, 193, 7));
        aceptar.setForeground(new Color(40, 40, 40));
        aceptar.setFocusPainted(false);
        aceptar.setPreferredSize(new Dimension(110, 36));
        aceptar.addActionListener(e -> dialogo.dispose());
        pie.add(aceptar);
        principal.add(pie, BorderLayout.SOUTH);
        dialogo.setContentPane(principal);
        dialogo.getRootPane().setDefaultButton(aceptar);
        dialogo.setVisible(true);
    }

    private void registrar() {
        if (carrito.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Agrega uno o más productos antes de registrar la venta.");
            return;
        }
        if (!confirmarVenta()) return;

        try {
            int productosDiferentes = carrito.size();
            ResultadoVenta resultado = gestor.realizarVenta(idUsuario, new LinkedHashMap<>(carrito));
            mostrarVentaCompletada(resultado, productosDiferentes);
            carrito.clear();
            refrescarCarrito();
            txtCantidad.setText("1");
            cargarProductos();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "No se pudo registrar la venta:\n" + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            cargarProductos();
        }
    }
}
