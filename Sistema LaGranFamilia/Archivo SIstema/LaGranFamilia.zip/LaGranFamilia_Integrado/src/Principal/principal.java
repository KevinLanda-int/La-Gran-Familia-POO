package Principal;

import javax.swing.SwingUtilities;
import Interfaz.Login;
import Interfaz.DialogosEstilo;

public class principal {
    public static void main(String[] args) {
        DialogosEstilo.aplicar();
        SwingUtilities.invokeLater(() -> new Login().setVisible(true));
    }
}
