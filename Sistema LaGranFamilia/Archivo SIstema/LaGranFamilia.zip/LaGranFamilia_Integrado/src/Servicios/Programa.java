package Servicios;

import javax.swing.SwingUtilities;
import Interfaz.Login;

public class Programa {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Login().setVisible(true));
    }
}
